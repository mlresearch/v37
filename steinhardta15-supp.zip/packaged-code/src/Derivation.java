import java.util.*;
public class Derivation implements Comparable<Derivation> {
  Derivation prev;
  int x, y;
  double score;
  public Derivation(){
    prev = this;
    x = 0;
    y = 0;
    score = 0.0;
  }
  public Derivation(Derivation prev, int x, int y){
    this.prev = prev;
    this.x = x;
    this.y = y;
    score = prev.score;
    score += Math.log(Global.pT.get(new Prefix(prev), x)) + Math.log(Global.pE[x][y]);
  }
  @Override
  public int compareTo(Derivation other){
    return Double.compare(other.score, score);
  }

}
