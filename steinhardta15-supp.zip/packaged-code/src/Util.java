import java.util.*;
import fig.basic.LogInfo;
import fig.basic.StatFig;
public class Util {
  public static int[] toInts(String line){
    String[] toks = line.split("\\s");
    int[] ret = new int[toks.length];
    for(int i = 0; i < toks.length; i++){
      ret[i] = Integer.parseInt(toks[i]);
    }
    return ret;
  }

  public static <T> List<T> sortedKeys(final Map<T, Double> x){
    List<T> keys = new ArrayList(x.keySet());
    Collections.sort(keys, new Comparator<T>(){
      @Override
      public int compare(T a, T b){
        return -Double.compare(x.get(a), x.get(b));
      }
    });
    return keys;
  }


  public static <T> StatFig wrapFig(Boolean x){
    StatFig ret = new StatFig();
    if(x != null) {
      ret.add(x);
    }
    return ret;
  }
  public static StatFig wrapFig(Double x){
    return wrapFig(x, 1);
  }
  public static StatFig wrapFig(Double x, int k){
    StatFig ret = new StatFig();
    if(x != null){
      for(int i=0;i<k;i++){
        ret.add(x);
      }
    }
    return ret;
  }

  public static <T> List<T> singleton(T x){
    List<T> ret = new ArrayList<T>();
    ret.add(x);
    return ret;
  }

  public static <T> Map<T, Double> singletonMap(T x){
    Map<T, Double> ret = new HashMap<T, Double>();
    ret.put(x, 1.0);
    return ret;
  }

  public static <T> T getSafe(List<T> x, int pos){
    return pos >= x.size() ? null : x.get(pos);
  }
  public static double getSafe(Map<String, Double> mp, String key){
    Double val = mp.get(key);
    if(val == null) return 0.0;
    else return val;
  }

  public static void add(Map<String, Double> mp, Map<String, Double> x){
    add(mp, x, 1.0);
  }
  public static void add(Map<String, Double> mp, Map<String, Double> x, double a){
    for(Map.Entry<String, Double> e : x.entrySet()){
      Util.add(mp, e.getKey(), a * e.getValue());
    }
  }
  public static void add(Map<String, Double> mp, String x){
    Util.add(mp, x, 1.0);
  }
  public static void add(Map<String, Double> mp, String x, double v){
    Double u = mp.get(x);
    if(u == null) mp.put(x, v);
    else mp.put(x, u+v);
  }
  public static <T> void addLSE(Map<T, Double> mp, Map<T, Double> x){
    for(Map.Entry<T,Double> e : x.entrySet()){
      T key = e.getKey();
      Double val = e.getValue();
      Double cur = mp.get(key);
      if(cur == null) mp.put(key, val);
      else mp.put(key, Util.logsumexp(cur, val));
    }
  }

  public static double logsumexp(double x, double y){
    if(x == Double.NEGATIVE_INFINITY) return y;
    else if(y == Double.NEGATIVE_INFINITY) return x;
    else if(x < y) return y + Math.log(1 + Math.exp(x-y));
    else return x + Math.log(1 + Math.exp(y-x));
  }

  // TODO this is slower than writing a special-purpose method
  public static double logistic(double x){
    return -logsumexp(0.0, -x);
  }

  public static double logNChooseK(int n, int k){
    return logFactorial(n) - logFactorial(k) - logFactorial(n-k);
  }
  public static double logFactorial(int n){
    double ret = 0.0;
    for(int i=2;i<=n;i++) ret += Math.log(i);
    return ret;
  }

  public static <T> void printMap(Map<T, Double> map){
    if(map.size() == 0) return;
    ArrayList<Map.Entry<T, Double> > list = new ArrayList<Map.Entry<T, Double> >(map.entrySet());
    Collections.sort(list, new Comparator<Map.Entry<T, Double> >(){
      @Override
      public int compare(Map.Entry<T, Double> x, Map.Entry<T, Double> y){
        return -Double.compare(Math.abs(x.getValue()), Math.abs(y.getValue()));
      }
    });
    double largest = Math.min(1.0, Math.abs(list.get(0).getValue()));
    for(Map.Entry<T, Double> entry : list){
      if(Math.abs(entry.getValue()) >= 5e-2 * largest){
        LogInfo.logs("%s:\t%s", entry.getKey(), entry.getValue());
      }
    }
  }
}
class DefaultMap extends HashMap<Integer, Double> {
  private double defaultVal;
  public DefaultMap(double defaultVal){
    super();
    this.defaultVal = defaultVal;
  }
  @Override
  public Double get(Object key){
    Double ret = super.get(key);
    if(ret == null) return defaultVal;
    else return ret;
  }
}
