/* 
 * File:   Rex3.hpp
 * Author: Tanguy Urvoy <tanguy.urvoy@orange.com>
 *
 * Sample C++ code for REX3 dueling-bandit algorithm
 * See P. Gajane, T. Urvoy, F. Clérot 
 * "A Relative Exponential Weighing Algorithm for Adversarial Utility-based Dueling Bandits"
 * ICML 2015
 *
 * This sample code is provided as is without guarantees and 
 * for research purpose only.
 * 
 * Copyright Orange-Labs 
 *
 * Created on 16 december 2014, 16:12
 */

#ifndef REX3_HPP
#define	REX3_HPP

#include "common.hpp"

const unsigned period = 1;

class Rex3
{
protected:

    /// Algorithms parameters
	
	/// Number of arms
	unsigned K; 
	/// Horizon
	unsigned long T; 
	/// Regret boundaries
    double gmin, gmax;
    double Gmin, Gmax;
	/// Exploration parameter
    double gamma;

	
    /// Internal State (Non-copiable)
	
    std::vector<long double> R;
    std::vector<long double> P;
    double eps;
    unsigned t;
    bool auto_tune;
	
	/// check for float saturation
    bool Wflood;

    /// Update arm-picking probabilities
    void update_P(void);

public:

    /// Algorithm name
    static std::string name(void);

    /// Class builder
    Rex3(unsigned K, unsigned long T, double _gamma = 0, double gmin = 0, double gmax = 1);
    /// Copy (and state-reset) builder
    Rex3(const Rex3 & original);

	
    /// Decide which duel to play 
	///(the client/environment requests a decision)
    duel_t decide(void);

    /// Update internal state according to environment relative feedback
	/// (the client/environment provides a relative feedback)
    void feedback(duel_t duel, double outcome);

    /// Debug information
    inline std::string state_info(void);

};

/// Algorithm name

inline std::string Rex3::name(void)
{
    return "Rex3";
}


/// The client asks for a decision

inline duel_t Rex3::decide(void)
{
    return duel_t(draw_from_dist(P), draw_from_dist(P));
}



/// The client provides a feedback

inline void Rex3::feedback(duel_t duel, double outcome)
{
    // boost the winner whack the loser
    if (duel.first != duel.second) {
        double delta = 2*outcome - 1;
        R[duel.first] += delta / P[duel.first];
        R[duel.second] -= delta / P[duel.second];
    }
	
	// periodic updates
    if (t % period == 0) update_P();
    ++t;
}



/// Update arm picking probabilities

inline void Rex3::update_P(void)
{
    long double Wt = 0;
    for (unsigned i = 0; i != R.size(); ++i) {
        long double wi = exp(eps * R[i]);
        Wt += wi;
    }
	// float saturation may appear after more than 10^9 steps.
	Wflood = (Wt > std::numeric_limits<double>::max());
	
	// Here we simply stop updating the model
	// but on a real system it must raise an interruption or an event.
    if(Wflood) return;
	
    for (unsigned i = 0; i != P.size(); ++i) {
        long double wi = exp(eps * R[i]);
        P[i] = (1.0 - K * eps) * wi / Wt + eps;
    }
}


/// Class builder

inline Rex3::Rex3(unsigned K, unsigned long T, double _gamma, double gmin, double gmax) :
K(K), T(T),
gmin(gmin), gmax(gmax), Gmin(T*gmin), Gmax(T*gmax),
gamma(_gamma == 0 ? std::min(0.5, sqrt(K*log(K)) / sqrt((M_E - 2.0 * gmin*(M_E - 2) / K) * Gmax - Gmin * (4.0 - M_E) / 2.0 / K)) : _gamma),
R(K, 0.0), P(K, 1.0 / K), eps(gamma / K), t(1), auto_tune(_gamma == 0), Wflood(false)

{
}



/// Copy (and reset) builder

inline Rex3::Rex3(const Rex3 & orig) :
K(orig.K),T(orig.T),
gmin(orig.gmin), gmax(orig.gmax),
Gmin(orig.Gmin), Gmax(orig.Gmax),
gamma(orig.gamma),
R(K, 0.0), P(K, 1.0 / K), eps(gamma / K), t(1),
auto_tune(orig.auto_tune), Wflood(false)
{
}



#endif	/* REX3_HPP */

