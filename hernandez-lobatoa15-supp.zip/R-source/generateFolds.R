
set.seed(0)
load("data_1.dat")

k <- length(data$X)
n <- rep(0, k)

for (i in 1 : k)
	n[ i ] <- nrow(data$X[[ i ]])

folds <- list()

for (i in 1 : k) {
	folds[[ i ]] <- list()
	folds[[ i ]]$itrain <- matrix(0, 100, round(n[ i ] * 9 / 10))
	folds[[ i ]]$itest <- matrix(0, 100, n[ i ] - round(n[ i ] * 9 / 10))
}

	
for (j in 1 : k) {
	for (i in 1 : 100) {
		itrain <- sample(1 : n[ j ], round(n[ j ] * 9 / 10))
		itest <- (1 : n[ j ])[ -itrain ]
		folds[[ j ]]$itrain[ i, ] <- itrain
		folds[[ j ]]$itest[ i, ] <- itest
	}
}

save(folds, file = "folds.dat")


