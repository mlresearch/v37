import java.util.*;
public class Data {
  List plain, cipher;
  public Data(){
    plain = new ArrayList();
    cipher = new ArrayList();
  }
  void addPlain(int[] x){
    plain.add(x);
  }
  void addCipher(int[] x){
    cipher.add(x);
  }
}
