# We generate the data for the experiment

source("generate_data.R")

# We load the code of DMFS

source("ep_robust-multi-task-natural_noise.R")

indexSim <- 1

set.seed(indexSim)

# We load the samples

load(paste("data_", indexSim, ".dat", sep = ""))
load(paste("folds.dat", sep = ""))

# We split the data in train and test sets

n <- nrow(data$X[[ 1 ]])
index <- folds[[ 1 ]]$itrain[ indexSim, ]

# We standardize the data

k <- length(data$X)

# We generate the training and test sets

Xtrain <- list()
Xtest <- list()
Ytrain <- list()
Ytest <- list()

for (i in 1 : k) {

	Xtrain[[ i ]] <- (data$X[[ i ]][ index, ])
	Xtest[[ i ]] <- (data$X[[ i ]][ -index, ])
	Ytrain[[ i ]] <- (data$Y[[ i ]][ index ])
	Ytest[[ i ]] <- (data$Y[[ i ]][ -index ])

}

# We call the method

time <- system.time(ret <- ep_RM(Xtrain, Ytrain, class = FALSE, a0 = rep(1 - 1, 5), 
	b0 = rep(1 - 1, 5), alpha0 = 5, beta0 = 5, shared_noise = FALSE))

save(ret, file = "model.dat")

write.table(time[ 1 ], "time.txt", col.names = F, row.names = F)

# We evaluate the test error

error <- 0
for (i in 1 : k) {
	error <- error + sqrt(mean((Xtest[[ i ]] %*% ret$W[ , i ] - Ytest[[ i ]])^2))
}
error <- error / k

cat("Test RMSE:", error, "\n")

write.table(error, "test_rmse.txt", col.names = F, row.names = F)

error <- 0
for (i in 1 : k) {
	error <- error + sqrt(sum((ret$W[ , i ] - data$W[, i ])^2))
}
error <- error / k

cat("Rec RMSE:", error, "\n")

write.table(error, "rec_rmse.txt", col.names = F, row.names = F)
