##
# This file contains the required information for carrying out approximate inference in a model
# with probit likelihood
#

log_Zprobit <- function(mOld, vOld, y, varNoise) {
	pnorm(y * mOld / sqrt(vOld + varNoise * vOld^2), 0, 1, log.p = TRUE) + 
		0.5 * log(2 * pi) - 0.5 * log(vOld) + 0.5 * mOld^2 / vOld
}

dlog_Zprobit_dm <- function(mOld, vOld, y, varNoise) {
	exp(dnorm(y * mOld / sqrt(vOld + varNoise * vOld^2), 0, 1, log = TRUE) - 
		pnorm(y * mOld / sqrt(vOld + varNoise * vOld^2), 0, 1, log.p = TRUE)) * 
		y / sqrt(vOld + varNoise * vOld^2) + mOld / vOld
}

dlog_Zprobit_ds <- function(mOld, vOld, y, varNoise) {
	exp(dnorm(y * mOld / sqrt(vOld + varNoise * vOld^2), 0, 1, log = TRUE) - 
		pnorm(y * mOld / sqrt(vOld + varNoise * vOld^2), 0, 1, log.p = TRUE)) * 
		- 0.5 * y * mOld / (vOld + varNoise * vOld^2)^(3 / 2) * (1 + 2 * varNoise * vOld) - 0.5 / vOld - 0.5 * mOld^2 / vOld^2
}

d2log_Zprobit_dm2 <- function(mOld, vOld, y, varNoise) {
	
	log_ratio <- dnorm(y * mOld / sqrt(vOld + varNoise * vOld^2), 0, 1, log = TRUE) - 
		pnorm(y * mOld / sqrt(vOld + varNoise * vOld^2), 0, 1, log.p = TRUE)

	exp(log_ratio) * y / sqrt(vOld + varNoise * vOld^2) * 
		(- mOld / (vOld + varNoise * vOld^2) - exp(log_ratio) * y / sqrt(vOld + varNoise * vOld^2)) + 1 / vOld
}

d2log_Zprobit_ds2 <- function(mOld, vOld, y, varNoise) {

	log_ratio <- dnorm(y * mOld / sqrt(vOld + varNoise * vOld^2), 0, 1, log = TRUE) - 
		pnorm(y * mOld / sqrt(vOld + varNoise * vOld^2), 0, 1, log.p = TRUE)

	- exp(log_ratio) * (0.5 * mOld^2 / (vOld + varNoise * vOld^2)^2 * (1 + varNoise * vOld * 2) + 
		exp(dnorm(y * mOld / sqrt(vOld + varNoise * vOld^2), 0, 1, log = TRUE) -
                pnorm(y * mOld / sqrt(vOld + varNoise * vOld^2), 0, 1, log.p = TRUE)) *
                0.5 * y * mOld / (vOld + varNoise * vOld^2)^(3 / 2) * (1 + 2 * varNoise * vOld)) * 
		0.5 * y * mOld / (vOld + varNoise * vOld^2)^(3 / 2) * (1 + 2 * varNoise * vOld)  + 
	- exp(log_ratio) * (-3 / 4 * y * mOld / (vOld + varNoise * vOld^2)^(5 / 2) * (1 + 2 * varNoise * vOld)^2 + 
		0.5 * y * mOld / (vOld + varNoise * vOld^2)^(3 / 2) * (2 * varNoise)) + 0.5 / vOld^2 + mOld^2 / vOld^3
}


