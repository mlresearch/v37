import java.util.*;
import fig.basic.LogInfo;
import fig.basic.StatFig;
public class Infer {
  public static void update(List data){
    switch(Main.inferType){
      case Main.EXACT:
        updateExact(data); break;
      case Main.BEAM:
        updateBeam(data); break;
      case Main.ABSTRACT:
        updateAbstract(data); break;
      default:
        throw new RuntimeException("invalid inferType: " + Main.inferType);
    }
  }
    
  public static void updateExact(List data){
    int numWords = Global.numWords;
    double[] count1 = new double[numWords];
    double[][] count2 = new double[numWords][numWords];
    Params pTnew = Main.kn ? new KNTrie(0, Main.ngramLength, Main.KN_EPS, Main.KN_DISCOUNT, Global.pTinit)
                           : new Laplace(Global.pTinit);
    StatFig wordAcc = new StatFig();
    for(Object o : data){
      int[] words = (int[])o;
      int len = words.length;
      // now do forward-backward algorithm
      double[][] forward = new double[len+1][numWords];
      forward[0][0] = 1.0;
      for(int t=0;t<len;t++){
        double Z = 0.0;
        for(int j=0;j<numWords;j++){
          for(int i=0;i<numWords;i++){
            forward[t+1][j] += forward[t][i] * Global.pT.get(new Prefix(i), j);
          }
          forward[t+1][j] *= Global.pE[j][words[t]];
          Z += forward[t+1][j];
        }
        if(Z < 1e-6) LogInfo.logs("warning: Z = %s", Z);
        for(int j=0;j<numWords;j++){
          forward[t+1][j] /= Z;
        }
      }
      double[][] backward = new double[len+1][numWords];
      for(int j=0;j<numWords;j++){
        backward[len][j] = 1.0;
      }
      for(int t=len-1;t>=0;t--){
        double Z = 0.0;
        for(int j=0;j<numWords;j++){
          for(int i=0;i<numWords;i++){
            backward[t][j] += backward[t+1][i] * Global.pT.get(new Prefix(j), i) * Global.pE[i][words[t]];
          }
          Z += backward[t][j];
        }
        if(Z < 1e-6) LogInfo.logs("warning: Z = %s", Z);
        for(int j=0;j<numWords;j++){
          backward[t][j] /= Z;
        }
      }
      double[][] combined = new double[len+1][numWords];
      double[] good = new double[len];
      for(int t=0;t<=len;t++){
        double Z = 0.0;
        for(int j=0;j<numWords;j++){
          combined[t][j] = forward[t][j] * backward[t][j];
          Z += combined[t][j];
        }
        if(Main.updateLM && t < len){
          for(int j=0;j<numWords;j++){
            for(int j2=0;j2<numWords;j2++){
              double wt = forward[t][j] * backward[t+1][j2] * Global.pT.get(new Prefix(j), j2) * Global.pE[j2][words[t]] / Z;
              pTnew.add(new Prefix(j2), j, wt);
            }
          }
        }
        if(Z < 1e-6) LogInfo.logs("warning: Z = %s", Z);
        for(int j=0;j<numWords;j++){
          combined[t][j] /= Z;
          if(t>0){
            count1[j] += combined[t][j];
            count2[j][words[t-1]] += combined[t][j];
            if(words[t-1] == Global.key.get(j)) good[t-1] += combined[t][j];
          }
        }
      }
      for(int t=0;t<len;t++) wordAcc.add(good[t] > 0.5);
      //LogInfo.logs("current word accuracy: %s", wordAcc);
      LogInfo.printProgStatus();
    }
    LogInfo.logs("final word accuracy: %s", wordAcc);
    if(Main.updateLM) Global.pT = pTnew;
    for(int i = 1; i < numWords; i++){
      if(count1[i] < 1e-6) LogInfo.logs("warning: count1[%s] = %s", i, count1[i]);
      for(int j = 0; j < numWords; j++){
        Global.pE[i][j] = count2[i][j] / count1[i];
      }
    }
  }

  public static void updateBeam(List data){
    int numWords = Global.numWords;
    double[] count1 = new double[numWords];
    double[][] count2 = new double[numWords][numWords];
    Params pTnew = Main.kn ? new KNTrie(0, Main.ngramLength, Main.KN_EPS, Main.KN_DISCOUNT, Global.pTinit)
                           : new Laplace(Global.pTinit);
    StatFig wordAcc = new StatFig();
    for(Object o : data){
      int[] words = (int[])o;
      int len = words.length;
      List<Derivation> beam = new ArrayList<Derivation>();
      beam.add(new Derivation());
      for(int t = 0; t < len; t++){
        List<Derivation> prevBeam = beam;
        beam = new ArrayList<Derivation>();
        for(int j = 0; j < numWords; j++){
          for(Derivation deriv : prevBeam){
            beam.add(new Derivation(deriv, j, words[t]));
          }
        }
        Collections.sort(beam);
        if(t+1 < len && beam.size() > Main.beamSize){
          beam = beam.subList(0, Main.beamSize);
        }
      }
      double logZ = Double.NEGATIVE_INFINITY;
      for(Derivation deriv : beam){
        logZ = Util.logsumexp(logZ, deriv.score);
      }
      if(logZ == Double.NEGATIVE_INFINITY){
        LogInfo.logs("warning: logZ = %s", logZ);
      }
      double[] good = new double[len];
      for(Derivation deriv : beam){
        double wt = Math.exp(deriv.score - logZ);
        Derivation cur = deriv;
        int p = len-1;
        while(cur.x != 0){
          if(cur.y == Global.key.get(cur.x)) good[p] += wt;
          p--;
          if(Main.updateLM){
            boolean incr = true;
            double thresh = 0.01, thresh2 = 1e-6;
            boolean small = wt < thresh2;
            if(wt < thresh){
              if(Math.random() < wt / thresh){
                wt = thresh;
              } else {
                incr = false;
              }
            }
            if(small) numSmall++;
            else if(!incr) numMed++;
            else numBig++;
            if(incr){
              pTnew.add(new Prefix(cur.prev), cur.x, wt);
            }
          }
          count1[cur.x] += wt;
          count2[cur.x][cur.y] += wt;
          cur = cur.prev;
        }
      }
      for(int t = 0; t < len; t++) wordAcc.add(good[t] > 0.5);
      //LogInfo.logs("current word accuracy: %s", wordAcc);
      LogInfo.printProgStatus();
    }
    LogInfo.logs("final word accuracy: %s", wordAcc);
    if(Main.updateLM) Global.pT = pTnew;
    double eps = 0.1 / numWords;
    for(int i = 1; i < numWords; i++){
      for(int j = 0; j < numWords; j++){
        Global.pE[i][j] = (count2[i][j] + eps) / (count1[i] + eps * numWords);
      }
    }
  }

  static int numSmall = 0, numMed = 0, numBig = 0;
  public static void updateAbstract(List data){
    int numWords = Global.numWords;
    double[] cE1 = new double[numWords];
    double[][] cE2 = new double[numWords][numWords];
    Params pTnew = Main.kn ? new KNTrie(0, Main.ngramLength, Main.KN_EPS, Main.KN_DISCOUNT, Global.pTinit)
                           : new Laplace(Global.pTinit);
    int _i = 0;
    StatFig wordAcc = new StatFig();
    for(Object o : data){
      int[] words = (int[])o;
      int len = words.length;
      int[] lcaExpand, lcaMerge;
      List<ExpandDerivation>[] beamExpand = new List[len+1];
      List<MergeDerivation>[] beamMerge = new List[len+1];
      lcaMerge = new int[1];
      beamExpand[0] = new ArrayList<ExpandDerivation>();
      beamMerge[0] = new ArrayList<MergeDerivation>();
      ExpandDerivation initExpand = new ExpandDerivation();
      MergeDerivation initMerge = new MergeDerivation(initExpand);
      initMerge.prev = initMerge;
      beamExpand[0].add(initExpand);
      beamMerge[0].add(initMerge);
      
      for(int t = 0; t < len; t++){
        // important invariant: both beamExpand and beamMerge 
        // are lexicographically (from end to start) sorted

        // expand from previous step
        lcaExpand = new int[numWords * lcaMerge.length];
        beamExpand[t+1] = new ArrayList<ExpandDerivation>();
        int p = 0;
        for(int j = 0; j < numWords; j++){
          int q = 0;
          for(MergeDerivation deriv : beamMerge[t]){
            beamExpand[t+1].add(new ExpandDerivation(deriv, j, words[t]));
            if(q+1 < lcaMerge.length){
              lcaExpand[p++] = lcaMerge[q++] + 1;
            } else {
              lcaExpand[p++] = 0;
            }
          }
        }

        double logZExpand = Double.NEGATIVE_INFINITY;
        for(ExpandDerivation deriv : beamExpand[t+1]){
          logZExpand = Util.logsumexp(logZExpand, deriv.score);
        }
        for(ExpandDerivation deriv : beamExpand[t+1]){
          deriv.registerLen(logZExpand);
        }

        if(t+1 < len){
          // sort by mass
          final List<ExpandDerivation> beamExpandFinal = beamExpand[t+1]; // stupid JAVA hack to allow sorting
          int size = beamExpandFinal.size();
          Integer[] byMass = new Integer[size];
          for(int j=0;j<size;j++) byMass[j] = j;
          Arrays.sort(byMass, new Comparator<Integer>(){
            @Override
            public int compare(Integer lhs, Integer rhs){
              return Double.compare(beamExpandFinal.get(rhs).score,
                                    beamExpandFinal.get(lhs).score);
            }
          });
          boolean[] isTarget = new boolean[size];
          for(int j=0;j<Math.min(Main.beamSize,size);j++){
            isTarget[byMass[j]]=true;
          }

          // merge beam elements into highest-scoring elements
          lcaMerge = new int[Math.min(Main.beamSize,size)+1];
          beamMerge[t+1] = new ArrayList<MergeDerivation>();
          for(int j=0;j<size;j++){
            if(isTarget[j]){
              beamMerge[t+1].add(new MergeDerivation(beamExpandFinal.get(j)));
            }
          }
          beamMerge[t+1].add(new MergeDerivation());
          p = beamMerge[t+1].size()-1;
          LinkedList<MergeDerivation> stack = new LinkedList<MergeDerivation>();
          stack.add(beamMerge[t+1].get(p));
          int INF = 99999;
          int lcp = INF;
          for(int j=size-1;j>=0;j--){
            lcp = Math.min(lcp, lcaExpand[j]);
            while(lcp < stack.getLast().len) stack.removeLast();
            if(isTarget[j]){
              lcaMerge[--p] = lcp;
              stack.add(beamMerge[t+1].get(p));
              lcp = INF;
            } else {
              stack.getLast().absorb(beamExpandFinal.get(j));
            }
          }
        }
      }

      // done constructing beams, now compute scores
      double logZ = Double.NEGATIVE_INFINITY;
      for(ExpandDerivation deriv : beamExpand[len]){
        logZ = Util.logsumexp(logZ, deriv.score);
        deriv.back = 0.0;
      }
      double[] good = new double[len];
      for(int t = len; t > 0; t--){
        if(t < len){
          for(MergeDerivation deriv : beamMerge[t]) deriv.backprop();
        }
        for(ExpandDerivation deriv : beamExpand[t]){
          double wt = Math.exp(deriv.score + deriv.back - logZ);
          cE1[deriv.x] += wt;
          cE2[deriv.x][deriv.y] += wt;
          if(deriv.y == Global.key.get(deriv.x)) good[t-1] += wt;
          if(Main.updateLM){
            boolean incr = true;
            double thresh = 0.01, thresh2 = 1e-6;
            boolean small = wt < thresh2;
            if(wt < thresh){
              if(Math.random() < wt / thresh){
                wt = thresh;
              } else {
                incr = false;
              }
            }
            if(small) numSmall++;
            else if(!incr) numMed++;
            else numBig++;
            if(incr){
              pTnew.add(new Prefix(deriv.prev), deriv.x, wt);
            }
          }
          deriv.backprop();
        }
      }
      for(int t = 0; t < len; t++) wordAcc.add(good[t] > 0.5);
      //LogInfo.logs("current word accuracy: %s", wordAcc);

      if(Main.updateLM){
        LogInfo.logs("%d / %d / %d (%.2f vs %.2f savings)", numSmall, numMed, numBig, 
                                                            100.0 * (numSmall + numMed) / (double) (numSmall + numMed + numBig), 
                                                            100.0 * numSmall / (double) (numSmall + numMed + numBig));
      }
      LogInfo.printProgStatus();
      //if(++_i % 100 == 0) Global.printLens();
    }
    LogInfo.logs("final word accuracy: %s", wordAcc);

    // update counts
    if(Main.updateLM) Global.pT = pTnew;
    double epsE = 0.1 / numWords;
    for(int i = 1; i < numWords; i++){
      for(int  j = 0; j < numWords; j++){
        Global.pE[i][j] = (cE2[i][j] + epsE) / (cE1[i] + numWords * epsE);
      }
    }
  }
}
