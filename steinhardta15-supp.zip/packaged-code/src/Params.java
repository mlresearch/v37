import java.util.*;
public interface Params {
  void add(Prefix p, int i, double wt);
  double get(Prefix p, int i);
}
