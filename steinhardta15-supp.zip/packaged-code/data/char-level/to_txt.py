f = open('plain.dat', 'r')
g = open('key.dat', 'r')
keys = dict()
for line in g:
  toks = line.rstrip("\n").split()
  keys[int(toks[0])] = toks[2]
for line in f:
  toks = map(int, line.rstrip("\n").split())
  print " ".join([keys[i] for i in toks])

