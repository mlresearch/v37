import java.util.*;
import gnu.trove.list.array.TIntArrayList;

//public class Prefix extends ArrayList<Integer> {
public class Prefix extends TIntArrayList {
  public Prefix(int ... prefix){
    super(prefix.length+1);
    add(prefix);
    //for(int i = 0; i < prefix.length; i++){
    //  add(prefix[i]);
    //}
  }
  //public Prefix(int[] prefix){
  //  super(prefix.length+1);
  //  add(prefix);
  //}
  public Prefix(MergeDerivation ptr){
    super(Main.ngramLength);
    int len = Main.ngramLength;
    int[] xs = new int[len-1];
    for(int i=1;i<len;i++){
      xs[len-1-i] = ptr.x;
      ptr = ptr.prev;
    }
    add(xs);
  }
  public Prefix(Derivation ptr){
    super(Main.ngramLength);
    int len = Main.ngramLength;
    int[] xs = new int[len-1];
    for(int i=1;i<len;i++){
      xs[len-1-i] = ptr.x;
      ptr = ptr.prev;
    }
    add(xs);
  }
}
