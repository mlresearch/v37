set.seed(0)

n <- 150
d <- 2000
k <- 12

for (i in 1 : 1) {

X <- list()
Y <- list()
W <- matrix(0, k, d)
W[ c(1, 2, 3, 5, 6, 7, 9, 10, 11, 12), 6:16 ] <- rt(length(c(W[ c(1, 2, 4, 5, 6, 8, 9, 10, 11, 12), 6:16 ])), 5)
W[ 8, c( 1, 3, 4, 20, 22, 23, 24) ] <- rt(length(c(W[ 8, c( 1, 3, 4, 20, 22, 23, 24) ])), 5)
W[ 4, c( 1, 2, 3, 5, 24, 25, 26) ] <- rt(length(c(W[ 4, c( 1, 2, 3, 5, 24, 25, 26) ])), 5)
W[ c(1, 2, 3), 19 ] <- rt(length(c(W[ c(1, 2, 3), 19 ])), 5)
W[ c(10, 11, 12), 21 ] <- rt(length(c(W[ c(10, 11, 12), 21 ])), 5) 

#W <- rbind(W, W, W)

for (j in 1 : nrow(W)) {
	X[[ j ]] <- matrix(rnorm(n * d), n, d)
	w <- W[ j, ]
	Y[[ j ]] <- c(X[[ j ]] %*% w) + rnorm(n, 0, sqrt(.5))
}

	data <- list(X = X, Y = Y, W = t(W))
	save(data, file = paste("data_", i, ".dat", sep = ""))

	print(i)
}

source("generateFolds.R")

