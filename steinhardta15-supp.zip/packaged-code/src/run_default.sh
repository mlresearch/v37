#!/bin/bash
./run.py --compile --name default
echo "See state/execs/default/ for results"
./run.py --run --name default --dataset ../data/char-level --iterations 20 --inference 2 --ngram 3 --kn --B 10
