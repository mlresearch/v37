##
# Year: 2014
#
#

#library(doMC)

source("probit.R")
source("beta.R")
source("SB_prior.R")
source("SB_prior_natural.R")

#log_conv_SB <- function(m,s) log_conv_Gauss_natural_paramters(m, s, 1)
#dlog_conv_SB_dm <- function(m,s) dlog_conv_Gauss_natural_paramters_dm(m, s, 1)
#dlog_conv_SB_ds <- function(m,s) dlog_conv_Gauss_natural_paramters_ds(m, s, 1)

sigmoid <- function(x) 1 / (1 + exp(-x))
logit <- function(x) log(x / (1 - x))

##
# Function: epRM
#
# Description: Trains a bayesian model using the robust prior 
#
# Arguments: 
#		X -> a matrix containing the attributes of the training data (one row per sample)
#		Y -> a vector with the class labels 1 or -1
#		sigma2 -> Variance of the noise
#		class -> A boolean which indicates binary classification or regression 
#			Important, for classification, we assume that the first componentis one, and is always included in the model.
#		a0 -> initial parameters of the prior for the betas distributions (natural parameters) (z, omega, gamma, tau, eta)
#		b0 -> initial parameters of the prior for the betas distributions (natural parameters) (z, omega, gamma, tau, eta)
#		verbose -> shall we print information?
# 		alpha0 <- Parameter of the inverse gamma prior for the noise (equal to N/2, where N is the number of observations)
#		beta0 <- Parameter of the inverse gamma prior for the noise (equal to 2 * alpha0 observations with variance beta0 / 2 * alpha0).
#
# Returns: 	A ranking of the features 
#

ep_RM <- function(X, Y, class = FALSE, a0 = rep(0, 5), b0 = rep(0, 5), verbose = FALSE, 
	alpha0 = 0, beta0 = 0, initial_damping = NULL, n_cores = 1, shared_noise = TRUE) {
	
	# We initialize the posterior approximation

	a <- initialize_approximation(X, Y, class, a0, b0, alpha0, beta0, n_cores, shared_noise)

	iters <- 0
	convergence <- FALSE

	if (is.null(initial_damping))
		damping <- .5
	else
		damping <- initial_damping

	q <- compute_titled_distribution(a)

	evidence_old <- +Inf

	while (iters < 2e2 && ! convergence) {

		aOld <- a

		valid_parameters <- FALSE
		factor <- 1

		while (! valid_parameters) {

			a <- aOld

			# We process the factors 

			if (class == TRUE)
				a <- process_likelihood_factors(q, a, factor * damping)
			else
				a <- process_likelihood_factors_regression(q, a, factor * damping)

			a <- process_prior_model_coefficients(q, a, factor * damping)

			a <- process_prior_binary_latent_variables(q, a, factor * damping)

			qNew <- compute_titled_distribution(a)

			valid_parameters <- all(qNew$v_w > 0) & all(sapply(qNew$v_targets, function(x) all(x > 0))) & 
				qNew$a_z > -1 & qNew$b_z > -1 & qNew$a_omega > -1 & qNew$b_omega > -1 & qNew$a_gamma > -1 & qNew$b_gamma > -1 &
				qNew$a_tau > -1 & qNew$b_tau > -1 & qNew$a_eta > -1 & qNew$b_eta > -1

			if (valid_parameters == FALSE) {
				factor <- factor * 0.5
				if (verbose)
					cat("\tReducing damping size:", damping * factor, "\n")
			}

		}

		# We look for convergence in the EP algorithm

		cat("iter:", iters, " ")

#		convergence <- check_convergence(a, aOld, verbose, damping)
		convergence <- check_convergence_q(qNew, q, TRUE, damping)
	
		iters <- iters + 1

		damping <- damping * 0.99

		q <- qNew

#		evidence_new <- evaluate_evidence(a, class)
#		cat("Itr:", iters, "logZ:", evaluate_evidence(a, class), "Change:", evidence_new - evidence_old, 
#			"Percnt:", abs(evidence_new - evidence_old) / abs(evidence_new), "Damping:", damping, "\n")
#		if (abs(evidence_new - evidence_old) / abs(evidence_new) < 1e-3) convergence <- TRUE
#		evidence_old <- evidence_new
	}

	# We evaluate the models evidence

	logZ <- evaluate_evidence(a, class)

	q <- compute_titled_distribution(a)

	# We compute the probs that the coefficients are different from zero

	P1 <- sigmoid(matrix(q$logit_p_z, a$nTasks, a$d, byrow = TRUE)) * sigmoid(q$logit_p_eta)
	P2 <- sigmoid(matrix(-q$logit_p_z, a$nTasks, a$d, byrow = TRUE)) * sigmoid(matrix(q$logit_p_omega, a$nTasks, a$d)) * sigmoid(q$logit_p_tau)
	P3 <- sigmoid(matrix(-q$logit_p_z, a$nTasks, a$d, byrow = TRUE)) * sigmoid(matrix(-q$logit_p_omega, a$nTasks, a$d)) * 
		sigmoid(matrix(q$logit_p_gamma, a$nTasks, a$d, byrow = TRUE))

	P <- P1 + P2 + P3

	# We return the model evidence, the posterior approximation and the feature ranking
	# W and P have in each column a task and in each row a model coefficient

	list(logZ = logZ, a = a, q = q, P = t(P), W = t(q$m_w))
}

##
# Function: initialize_approximation
#
# Description: initializes the posterior approximation
#
# Arguments: 
#		X -> a list containing the attributes of the training data (one row per sample)
#		Y -> a list with the class labels 1 or -1
#		class -> A boolean which indicates classification or regression 
#		a0 -> initial parameters of the prior for the betas distributions (natural parameters)
#		b0 -> initial parameters of the prior for the betas distributions (natural parameters)
#
# Returns: 	The posterior approximation
#

initialize_approximation <- function(X, Y, class, a0, b0, alpha0, beta0, n_cores, shared_noise) {

        # We set some useful constants. This is the number of tasks

	nTasks <- length(X)

	# We add the bias component in case of a classification problem

	if (class == TRUE) {
		for (k in 1 : nTasks)	
			X[[ k ]] <- cbind(rep(1, nrow(X[[ k ]])), X[[ k ]])
	}

	d <- ncol(X[[ 1 ]])

	# These are the parameters for the spike and slab prior

	sTilde <- muTilde <- matrix(0, nTasks, d)
	nuTilde <- matrix(0.01, nTasks, d)
	zTilde <- omegaTilde <- gammaTilde <- tauTilde <- etaTilde <- matrix(0, nTasks, d)

	# These are the parameters for the Bernoulli priors

	s_zTilde <- b_zTilde <- a_zTilde <- logit_zTilde <- rep(0, d)
	s_omegaTilde <- b_omegaTilde <- a_omegaTilde <- logit_omegaTilde <- rep(0, nTasks)
	s_gammaTilde <- b_gammaTilde <- a_gammaTilde <- logit_gammaTilde <- rep(0, d)
	s_tauTilde <- b_tauTilde <- a_tauTilde <- logit_tauTilde <- matrix(0, nTasks, d)
	s_etaTilde <- b_etaTilde <- a_etaTilde <- logit_etaTilde <- matrix(0, nTasks, d)

	v0 <- matrix(1e-10, nTasks, d)

	# These factors will approximate the likelihood

	bTilde <- aTilde <- cTilde <- vTilde <- mTilde <- list()
		
	for (k in 1 : nTasks) {

		# We specify the prior for the targets depending on the type of problem

		if (class == TRUE) {
			mTilde[[ k ]] <- rep(0, nrow(X[[ k ]]))
			vTilde[[ k ]] <- rep(1, nrow(X[[ k ]]))
			cTilde[[ k ]] <- rep(- 0.5 * log(2 * pi), nrow(X[[ k ]]))
		} else {

			sigma2 <- (beta0 / (alpha0 - 2))

			mTilde[[ k ]] <- Y[[ k ]] / sigma2
			vTilde[[ k ]] <- rep(sigma2^-1, nrow(X[[ k ]]))
			cTilde[[ k ]] <- - 0.5 * log(2 * pi * sigma2) - 0.5 *  mTilde[[ k ]]^2 / vTilde[[ k ]]
			aTilde[[ k ]] <- rep(0, nrow(X[[ k ]]))
			bTilde[[ k ]] <- rep(0, nrow(X[[ k ]]))
		}
	}

	fTildes <- list(mTilde = mTilde, vTilde = vTilde, cTilde = cTilde, aTilde = aTilde, bTilde = bTilde)

	gTildes <- list(sTilde = sTilde, nuTilde = nuTilde, muTilde = muTilde, zTilde = zTilde, omegaTilde = omegaTilde,
		gammaTilde = gammaTilde, tauTilde = tauTilde, etaTilde = etaTilde) 

	hTildes_z <- list(s_zTilde = s_zTilde, b_zTilde = b_zTilde, a_zTilde = a_zTilde, logit_zTilde = logit_zTilde)

	hTildes_omega <- list(s_omegaTilde = s_omegaTilde, b_omegaTilde = b_omegaTilde, a_omegaTilde = a_omegaTilde, 
		logit_omegaTilde = logit_omegaTilde)

	hTildes_gamma <- list(s_gammaTilde = s_gammaTilde, b_gammaTilde = b_gammaTilde, a_gammaTilde = a_gammaTilde, 
		logit_gammaTilde = logit_gammaTilde)

	hTildes_tau <- list(s_tauTilde = s_tauTilde, b_tauTilde = b_tauTilde, a_tauTilde = a_tauTilde, 
		logit_tauTilde = logit_tauTilde)

	hTildes_eta <- list(s_etaTilde = s_etaTilde, b_etaTilde = b_etaTilde, a_etaTilde = a_etaTilde, 
		logit_etaTilde = logit_etaTilde)

	lTildes_z <- list(s_Tilde = -lbeta(a0[ 1 ] + 1, b0[ 1 ] + 1), a_Tilde = a0[ 1 ], b_Tilde = b0[ 1 ]) 
	lTildes_omega <- list(s_Tilde = -lbeta(a0[ 2 ] + 1, b0[ 2 ] + 1), a_Tilde = a0[ 2 ], b_Tilde = b0[ 2 ]) 
	lTildes_gamma <- list(s_Tilde = -lbeta(a0[ 3 ] + 1, b0[ 3 ] + 1), a_Tilde = a0[ 3 ], b_Tilde = b0[ 3 ]) 
	lTildes_tau <- list(s_Tilde = -lbeta(a0[ 4 ] + 1, b0[ 4 ] + 1), a_Tilde = a0[ 4 ], b_Tilde = b0[ 4 ]) 
	lTildes_eta <- list(s_Tilde = -lbeta(a0[ 5 ] + 1, b0[ 5 ] + 1), a_Tilde = a0[ 5 ], b_Tilde = b0[ 5 ]) 

	if (class == FALSE) {
		if (shared_noise == TRUE) 
			kTildes <- list(aTilde = alpha0, bTilde = beta0, sTilde = (alpha0 - 1) * log(beta0) - lgamma(alpha0 - 1))
		 else
			kTildes <- list(aTilde = rep(alpha0, nTasks), 
				bTilde = rep(beta0, nTasks), sTilde = rep((alpha0 - 1) * log(beta0) - lgamma(alpha0 - 1), nTasks))
	} else
		kTildes <- NULL

	if (n_cores != 1) {
		registerDoMC(cores = n_cores)	
	}

	list(fTildes = fTildes, gTildes = gTildes, hTildes_z = hTildes_z, hTildes_omega = hTildes_omega, hTildes_gamma = hTildes_gamma,
		hTildes_tau = hTildes_tau, hTildes_eta = hTildes_eta,  kTildes = kTildes, class = class,
		lTildes_z = lTildes_z, lTildes_omega = lTildes_omega, lTildes_gamma = lTildes_gamma, 
		lTildes_tau = lTildes_tau, lTildes_eta = lTildes_eta, v0 = v0, X = X, Y = Y, sigma2 = sigma2, d = d, nTasks = nTasks, 
		n_cores = n_cores, shared_noise = shared_noise)
}

##
# Function: compute_titled_distribution
#
# Description: computes the means and the variances of the marignals of the posterior
#
# Arguments: 
#		a -> posterior approximation
#
# Returns: 	posterior approximation
#

compute_titled_distribution <- function(a) {

        # We set some useful constants. 

	d <- a$d

	v_w <- m_w <- matrix(0, a$nTasks, d)
	m_targets <- list()
	v_targets <- list()

	# These are the posterior of the targets one multiplied by the delta function

	m_targets_delta <- list()
	v_targets_delta <- list()

	# First we reconstruct the Gaussian approximation over the Targets

	for (k in 1 : a$nTasks) {
		v_targets[[ k ]] <- a$fTildes$vTilde[[ k ]]^-1
		m_targets[[ k ]] <- v_targets[[ k ]] * a$fTildes$mTilde[[ k ]]
	}

	# Second we reconstruct the Bernoulli approximation over the latent variables

	logit_p_z <- colSums(a$gTildes$zTilde) + a$hTildes_z$logit_zTilde
	logit_p_omega <- rowSums(a$gTildes$omegaTilde) + a$hTildes_omega$logit_omegaTilde
	logit_p_gamma <- colSums(a$gTildes$gammaTilde) + a$hTildes_gamma$logit_gammaTilde
	logit_p_tau <- a$gTildes$tauTilde + a$hTildes_tau$logit_tauTilde
	logit_p_eta <- a$gTildes$etaTilde + a$hTildes_eta$logit_etaTilde

	# If it is a classification problem we assume the first feature is an oulier feature
	# that is always activated

	if (a$class == TRUE) {
		logit_p_z[ 1 ] <- 1e4
		logit_p_eta[ ,1 ] <- 1e4
		logit_p_gamma[ 1 ] <- 0
		logit_p_tau[ ,1 ] <- 0
	}

	# Fourth we reconstruct the Beta approximation over the prior probabilities of the latent variables

	a_z <- sum(a$hTildes_z$a_zTilde) + a$lTildes_z$a_Tilde 
	b_z <- sum(a$hTildes_z$b_zTilde) + a$lTildes_z$b_Tilde 

	a_omega <- sum(a$hTildes_omega$a_omegaTilde) + a$lTildes_omega$a_Tilde 
	b_omega <- sum(a$hTildes_omega$b_omegaTilde) + a$lTildes_omega$b_Tilde 

	a_gamma <- sum(a$hTildes_gamma$a_gammaTilde) + a$lTildes_gamma$a_Tilde 
	b_gamma <- sum(a$hTildes_gamma$b_gammaTilde) + a$lTildes_gamma$b_Tilde 

	a_tau <- sum(a$hTildes_tau$a_tauTilde) + a$lTildes_tau$a_Tilde 
	b_tau <- sum(a$hTildes_tau$b_tauTilde) + a$lTildes_tau$b_Tilde 

	a_eta <- sum(a$hTildes_eta$a_etaTilde) + a$lTildes_eta$a_Tilde 
	b_eta <- sum(a$hTildes_eta$b_etaTilde) + a$lTildes_eta$b_Tilde 

	# Fourth we reconstruct the Gaussian approximation over the model coefficients 

	if (a$n_cores != 1)  {

		result <- foreach(k = 1 : a$nTasks) %dopar% {
		
			n <- nrow(a$X[[ k ]])
	
			# We extract the mean and the variance of the marginals
			# We compute first the lambda matrix and the upsilon vector
		
			tX <- t.default(a$X[[ k ]])
	
			dX <- matrix(a$gTildes$nuTilde[ k, ]^-1, n, d, byrow = TRUE) * a$X[[ k ]]
	#		U <- solve(diag(v_targets[[ k ]]) + a$X[[ k ]] %*% t.default(dX))
			U <- matrix(v_targets[[ k ]]^-1, n, n, byrow = TRUE) * solve(diag(length(v_targets[[ k ]])) + 
				(matrix(v_targets[[ k ]]^-1, n, d) * a$X[[ k ]]) %*% t.default(dX))
			UdX <- U %*% dX
	
			v_w <- a$gTildes$nuTilde[ k, ]^-1 - colSums(UdX * dX)
		
			v_aux <- c((m_targets[[ k ]] / v_targets[[ k ]]) %*% a$X[[ k ]] + a$gTildes$muTilde[ k, ])
		
			m_w <- c(a$gTildes$nuTilde[ k, ]^-1 * v_aux) - c(t.default(UdX) %*% (dX %*% v_aux))
	
			# Now we compute the posterior of the targets times the delta function 
	
			v_targets_delta <- rowSums(dX * a$X[[ k ]]) -  rowSums((a$X[[ k ]] %*% t(dX) %*% UdX) * a$X[[ k ]])
			m_targets_delta <- c(a$X[[ k ]] %*% m_w)
		
			list(m_w = m_w, v_w = v_w, v_targets_delta = v_targets_delta, m_targets_delta = m_targets_delta)
		}

		for (k in 1 : a$nTasks) {
			m_w[ k, ] <- result[[ k ]]$m_w
			v_w[ k, ] <- result[[ k ]]$v_w
			v_targets_delta[[ k ]] <- result[[ k ]]$v_targets_delta
			m_targets_delta[[ k ]] <- result[[ k ]]$m_targets_delta
		}

	} else {
		for (k in 1 : a$nTasks) {

			n <- nrow(a$X[[ k ]])
	
			# We extract the mean and the variance of the marginals
			# We compute first the lambda matrix and the upsilon vector
		
			tX <- t.default(a$X[[ k ]])
	
			dX <- matrix(a$gTildes$nuTilde[ k, ]^-1, n, d, byrow = TRUE) * a$X[[ k ]]
	#		U <- solve(diag(v_targets[[ k ]]) + a$X[[ k ]] %*% t.default(dX))
			U <- matrix(v_targets[[ k ]]^-1, n, n, byrow = TRUE) * solve(diag(length(v_targets[[ k ]])) + 
				(matrix(v_targets[[ k ]]^-1, n, d) * a$X[[ k ]]) %*% t.default(dX))
			UdX <- U %*% dX
	
			v_w[ k, ] <- a$gTildes$nuTilde[ k, ]^-1 - colSums(UdX * dX)
		
			v_aux <- c((m_targets[[ k ]] / v_targets[[ k ]]) %*% a$X[[ k ]] + a$gTildes$muTilde[ k, ])
		
			m_w[ k, ] <- c(a$gTildes$nuTilde[ k, ]^-1 * v_aux) - c(t.default(UdX) %*% (dX %*% v_aux))
	
			# Now we compute the posterior of the targets times the delta function 
	
			v_targets_delta[[ k ]] <- rowSums(dX * a$X[[ k ]]) -  rowSums((a$X[[ k ]] %*% t(dX) %*% UdX) * a$X[[ k ]])
			m_targets_delta[[ k ]] <- c(a$X[[ k ]] %*% m_w[ k, ])
		}
	}

	# Now the noise. We only work with natural parameters

	if (a$class == FALSE) {
		if (a$shared_noise == TRUE) {
			alpha <- rep(sum(sapply(a$fTildes$aTilde, function(x) sum(x))) + a$kTildes$aTilde, a$nTasks)
			beta <- rep(sum(sapply(a$fTildes$bTilde, function(x) sum(x))) + a$kTildes$bTilde, a$nTasks)
		} else {
			alpha <- sapply(a$fTildes$aTilde, function(x) sum(x)) + a$kTildes$aTilde
			beta <- sapply(a$fTildes$bTilde, function(x) sum(x)) + a$kTildes$bTilde
		}

		alphaNoise <- alpha 
		betaNoise <- beta
	} else {
		alphaNoise <- NULL
		betaNoise <- NULL
	}

	# We return a list with all the quantities computed

	list(m_w = m_w, v_w = v_w, m_targets = m_targets, v_targets = v_targets, logit_p_z = logit_p_z, 
		logit_p_omega = logit_p_omega, logit_p_gamma = logit_p_gamma, logit_p_tau = logit_p_tau, 
		logit_p_eta = logit_p_eta, a_z = a_z, b_z = b_z, a_omega = a_omega, b_omega = b_omega,
		a_gamma = a_gamma, b_gamma = b_gamma, a_tau = a_tau, b_tau = b_tau, a_eta = a_eta, b_eta = b_eta,
		m_targets_delta = m_targets_delta, v_targets_delta = v_targets_delta, alphaNoise = alphaNoise, betaNoise = betaNoise)
}

##
# Function: process_likelihood_factors_regression
#
# Description: process the terms of the prior
#
# Arguments: 
#
#		q -> Reconstructed Posteior approximation
#		a -> Posterior approximation
#		damping -> Damping parameter
#
# Returns: 	The updated factors
#


process_likelihood_factors_regression <- function(q, a, damping) {

	# We iterate for each learning task

	for (k in 1 : a$nTasks) {

		# First we compute an Old posterior distribution

		v_old <- (q$v_targets_delta[[ k ]]^-1 - a$fTildes$vTilde[[ k ]])
		m_old <- (q$m_targets_delta[[ k ]] / q$v_targets_delta[[ k ]] - a$fTildes$mTilde[[ k ]])
		alpha_old <- q$alphaNoise[ k ] - a$fTildes$aTilde[[ k ]]
		beta_old <- q$betaNoise[ k ] - a$fTildes$bTilde[[ k ]]

		to_sel <- v_old > 0 & alpha_old > 2 & beta_old > 0

		v_old <- v_old[ to_sel ]
		m_old <- m_old[ to_sel ]
		alpha_old <- alpha_old[ to_sel ]
		beta_old <- beta_old[ to_sel ]
		y <- a$Y[[ k ]][ to_sel ]

		# The inv. gamma factor is exp(-alpha_old * log(x) - beta_old / x)
		# We approximate the student t by a a gaussian with the same mean and variance

		nu <- (alpha_old - 1) * 2
		mean <- m_old / v_old
		var <- beta_old / (alpha_old - 2)
		
		logZ <- dnorm(y, m_old / v_old, sqrt(var + v_old^-1), log = TRUE) + 0.5 * log(2 * pi * v_old^-1) + 0.5 * m_old^2 / v_old + 
			lgamma(alpha_old - 1) - (alpha_old - 1) * log(beta_old) 

		dlogZdm_old <- - (m_old / v_old - y) / (var + v_old^-1) / v_old + m_old / v_old
		dlogZdv_old <- 0.5 * 1 / (var + v_old^-1) * 1 / v_old^2 - (y -  m_old / v_old) * m_old / v_old^2 / (var + v_old^-1) + 
				- 0.5 * (y -  m_old / v_old)^2 / (var + v_old^-1)^2 * 1 / v_old^2 - 0.5 / v_old - 0.5 * m_old^2 / v_old^2

		mean_new <- dlogZdm_old
		var_new <- (- 2 * dlogZdv_old - mean_new^2)

		varp1 <- beta_old / (alpha_old - 1)
		logZp1 <- dnorm(y, m_old / v_old, sqrt(varp1 + v_old^-1), log = TRUE) + 0.5 * log(2 * pi * v_old^-1) + 0.5 * m_old^2 / v_old + 
			lgamma(alpha_old) - (alpha_old) * log(beta_old)

		varp2 <- beta_old / alpha_old
		logZp2 <- dnorm(y, m_old / v_old, sqrt(varp2 + v_old^-1), log = TRUE) + 0.5 * log(2 * pi * v_old^-1) + 0.5 * m_old^2 / v_old + 
			lgamma(alpha_old + 1) - (alpha_old + 1) * log(beta_old) 

		first_moment_noise_new <- exp(logZp1 - logZ)  # This is equal to alpha_new - 1 / beta_new
		second_moment_noise_new <- exp(logZp2 - logZ) # This is equal to alpha_new * (alpha_new - 1) / beta_new^2

		alpha_new <- - second_moment_noise_new / (first_moment_noise_new^2 - second_moment_noise_new)
		beta_new <- (alpha_new - 1) / first_moment_noise_new

		# If we obtain invalid parameters for the gamma we do not do the update

		to_keep <- beta_new > 0 | alpha_new > 1
		var_new <- var_new[ to_keep ]
		mean_new <- mean_new[ to_keep ]
		alpha_new <- alpha_new[ to_keep ]
		beta_new <- beta_new[ to_keep ]
		v_old <- v_old[ to_keep ]
		m_old <- m_old[ to_keep ]
		alpha_old <- alpha_old[ to_keep ]
		beta_old <- beta_old[ to_keep ]
		logZ <- logZ[ to_keep ]

		to_sel[ which( to_sel == TRUE )[ ! to_keep ] ] <- FALSE

		# We compute the updated parameters of each factor


		new_vTilde <- var_new^-1 - v_old
		new_mTilde <- mean_new / var_new - m_old
		new_aTilde <- alpha_new - alpha_old
		new_bTilde <- beta_new - beta_old

		# We do the update

		a$fTildes$vTilde[[ k ]][ to_sel ] <- damping * new_vTilde + (1 - damping) * a$fTildes$vTilde[[ k ]][ to_sel ]
		a$fTildes$mTilde[[ k ]][ to_sel ] <- damping * new_mTilde + (1 - damping) * a$fTildes$mTilde[[ k ]][ to_sel ]
		a$fTildes$aTilde[[ k ]][ to_sel ] <- damping * new_aTilde + (1 - damping) * a$fTildes$aTilde[[ k ]][ to_sel ]
		a$fTildes$bTilde[[ k ]][ to_sel ] <- damping * new_bTilde + (1 - damping) * a$fTildes$bTilde[[ k ]][ to_sel ]

		# We compute the normalization constant

		a$fTildes$cTilde[[ k ]][ to_sel ] <- logZ - 0.5 * log(2 * pi * var_new) - 0.5 * (mean_new^2 / var_new) - 
			lgamma(alpha_new - 1) + (alpha_new - 1) * log(beta_new)
	}

	a
}

##
# Function: process_likelihood_factors
#
# Description: process the terms of the prior
#
# Arguments: 
#
#		Y -> Class labels
#		q -> Reconstructed Posteior approximation
#		a -> Posterior approximation
#		damping -> Damping parameter
#
# Returns: 	The updated factors
#


process_likelihood_factors <- function(q, a, damping) {

	# We iterate for each learning task

	for (k in 1 : a$nTasks) {

		# First we compute an Old posterior distribution

		v_old <- (q$v_targets_delta[[ k ]]^-1 - a$fTildes$vTilde[[ k ]])
		m_old <- (q$m_targets_delta[[ k ]] / q$v_targets_delta[[ k ]] - a$fTildes$mTilde[[ k ]])

		to_sel <- v_old > 0

		v_old <- v_old[ to_sel ]
		m_old <- m_old[ to_sel ]
		y <- sign(a$Y[[ k ]])[ to_sel ]

		log_Z <- log_Zprobit(m_old, v_old, y, a$sigma2[ k ]) 
		dlog_Z_dm <- dlog_Zprobit_dm(m_old, v_old, y, a$sigma2[ k ]) 
		dlog_Z_ds <- dlog_Zprobit_ds(m_old, v_old, y, a$sigma2[ k ]) 

		new_means <- dlog_Z_dm
		new_vars <- -2 * dlog_Z_ds - dlog_Z_dm^2

		new_vTilde <- new_vars^-1 - v_old
		new_mTilde <- new_means / new_vars - m_old

		a$fTildes$vTilde[[ k ]][ to_sel ] <- damping * new_vTilde + (1 - damping) * a$fTildes$vTilde[[ k ]][ to_sel ]
		a$fTildes$mTilde[[ k ]][ to_sel ] <- damping * new_mTilde + (1 - damping) * a$fTildes$mTilde[[ k ]][ to_sel ]
		a$fTildes$cTilde[[ k ]][ to_sel ] <- log_Z - 0.5 * log(2 * pi * new_vars) - 0.5 * new_means^2 / new_vars
	}

	a
}

##
# Function: process_prior_model_coefficients
#
# Description: process the terms of the prior
#
# Arguments: 
#		q -> reconstructed posterior
#		a -> posterior approximation
#		damping -> Damping factor to improve convergence. 
#
# Returns: 	The posterior approximation
#

process_prior_model_coefficients<- function(q, a, damping) {

	# We remove the approximate term from the posterior approximation

	v_old <- q$v_w^-1 - a$gTildes$nuTilde
	m_old <- q$m_w / q$v_w - a$gTildes$muTilde

	logit_p_z_old <- matrix(rep(q$logit_p_z, a$nTasks), a$nTasks, a$d, byrow = TRUE) - a$gTildes$zTilde
	logit_p_omega_old <- matrix(rep(q$logit_p_omega, a$d), a$nTasks, a$d) - a$gTildes$omegaTilde
	logit_p_gamma_old <- matrix(rep(q$logit_p_gamma, a$nTasks), a$nTasks, a$d, byrow = TRUE) - a$gTildes$gammaTilde
	logit_p_tau_old <- q$logit_p_tau - a$gTildes$tauTilde
	logit_p_eta_old <- q$logit_p_eta - a$gTildes$etaTilde

	# If one term has negative variance or missing we do not perform the update. This vectorizes things

	indx <- ! is.infinite(v_old) & v_old > 0
	v_old <- v_old[ indx ]; m_old <- m_old[ indx ]; v0 <- a$v0[ indx ]
	logit_p_z_old <- logit_p_z_old[ indx ]
	logit_p_omega_old <- logit_p_omega_old[ indx ]
	logit_p_gamma_old <- logit_p_gamma_old[ indx ]
	logit_p_tau_old <- logit_p_tau_old[ indx ]
	logit_p_eta_old <- logit_p_eta_old[ indx ]

	log_Zspike <- log_conv_Gauss_natural_paramters(m_old, v_old, v0)
	log_ZSB <- log_conv_SB(m_old, v_old)

	max <- pmax(log_ZSB, log_Zspike)

	log_Z_norm <- log(sigmoid(logit_p_z_old) * sigmoid(logit_p_eta_old) * exp(log_ZSB - max) +
		sigmoid(logit_p_z_old) * sigmoid(-logit_p_eta_old) * exp(log_Zspike - max) +
		sigmoid(-logit_p_z_old) * sigmoid(logit_p_omega_old) * sigmoid(logit_p_tau_old) * exp(log_ZSB - max) +
		sigmoid(-logit_p_z_old) * sigmoid(logit_p_omega_old) * sigmoid(-logit_p_tau_old) * exp(log_Zspike - max) +
		sigmoid(-logit_p_z_old) * sigmoid(-logit_p_omega_old) * sigmoid(logit_p_gamma_old) * exp(log_ZSB - max) +
		sigmoid(-logit_p_z_old) * sigmoid(-logit_p_omega_old) * sigmoid(-logit_p_gamma_old) * exp(log_Zspike - max)) + max 

	max_z <- pmax(0, logit_p_z_old)
	log_norm_z <- log(exp(- max_z) + exp(logit_p_z_old - max_z)) + max_z
	max_omega <- pmax(0, logit_p_omega_old)
	log_norm_omega <- log(exp(- max_omega) + exp(logit_p_omega_old - max_omega)) + max_omega
	max_gamma <- pmax(0, logit_p_gamma_old)
	log_norm_gamma <- log(exp(- max_gamma) + exp(logit_p_gamma_old - max_gamma)) + max_gamma
	max_tau <- pmax(0, logit_p_tau_old)
	log_norm_tau <- log(exp(- max_tau) + exp(logit_p_tau_old - max_tau)) + max_tau
	max_eta <- pmax(0, logit_p_eta_old)
	log_norm_eta <- log(exp(- max_eta) + exp(logit_p_eta_old - max_eta)) + max_eta
	
	log_Z <- log_Z_norm + log_norm_z + log_norm_omega + log_norm_gamma + log_norm_tau + log_norm_eta

	d_log_Z_dm <- (sigmoid(logit_p_z_old) * sigmoid(logit_p_eta_old) * exp(log_ZSB - log_Z_norm) * dlog_conv_SB_dm(m_old, v_old) +
		sigmoid(logit_p_z_old) * sigmoid(-logit_p_eta_old) * exp(log_Zspike - log_Z_norm) * 
		dlog_conv_Gauss_natural_paramters_dm(m_old, v_old, v0) + sigmoid(-logit_p_z_old) * sigmoid(logit_p_omega_old) * 
		sigmoid(logit_p_tau_old) * exp(log_ZSB - log_Z_norm) * dlog_conv_SB_dm(m_old, v_old) +
		sigmoid(-logit_p_z_old) * sigmoid(logit_p_omega_old) * sigmoid(-logit_p_tau_old) * exp(log_Zspike - log_Z_norm) *
		dlog_conv_Gauss_natural_paramters_dm(m_old, v_old, v0) + sigmoid(-logit_p_z_old) * sigmoid(-logit_p_omega_old) * 
		sigmoid(logit_p_gamma_old) * exp(log_ZSB - log_Z_norm) * dlog_conv_SB_dm(m_old, v_old) + sigmoid(-logit_p_z_old) * 
		sigmoid(-logit_p_omega_old) * sigmoid(-logit_p_gamma_old) * exp(log_Zspike - log_Z_norm) *
		dlog_conv_Gauss_natural_paramters_dm(m_old, v_old, v0))

	d_log_Z_ds <- (sigmoid(logit_p_z_old) * sigmoid(logit_p_eta_old) * exp(log_ZSB - log_Z_norm) * dlog_conv_SB_ds(m_old, v_old) +
                sigmoid(logit_p_z_old) * sigmoid(-logit_p_eta_old) * exp(log_Zspike - log_Z_norm) * 
		dlog_conv_Gauss_natural_paramters_ds(m_old, v_old, v0) + sigmoid(-logit_p_z_old) * sigmoid(logit_p_omega_old) * 
		sigmoid(logit_p_tau_old) * exp(log_ZSB - log_Z_norm) * dlog_conv_SB_ds(m_old, v_old) + sigmoid(-logit_p_z_old) * 
		sigmoid(logit_p_omega_old) * sigmoid(-logit_p_tau_old) * exp(log_Zspike - log_Z_norm) * 
		dlog_conv_Gauss_natural_paramters_ds(m_old, v_old, v0) + sigmoid(-logit_p_z_old) * sigmoid(-logit_p_omega_old) * 
		sigmoid(logit_p_gamma_old) * exp(log_ZSB - log_Z_norm) * dlog_conv_SB_ds(m_old, v_old) + sigmoid(-logit_p_z_old) * 
		sigmoid(-logit_p_omega_old) * sigmoid(-logit_p_gamma_old) * exp(log_Zspike - log_Z_norm) *
                dlog_conv_Gauss_natural_paramters_ds(m_old, v_old, v0))

	mean_new <- d_log_Z_dm
	var_new <- abs(-2 * d_log_Z_ds - d_log_Z_dm^2)

	## z latent variables

	d_sigmoid_dz <- sigmoid(logit_p_z_old) * (1 - sigmoid(logit_p_z_old))

	d_log_Z_dz <- d_sigmoid_dz * sigmoid(logit_p_eta_old) * exp(log_ZSB - log_Z_norm) +
		d_sigmoid_dz * sigmoid(-logit_p_eta_old) * exp(log_Zspike - log_Z_norm) +
		-d_sigmoid_dz * sigmoid(logit_p_omega_old) * sigmoid(logit_p_tau_old) * exp(log_ZSB - log_Z_norm) +
		-d_sigmoid_dz * sigmoid(logit_p_omega_old) * sigmoid(-logit_p_tau_old) * exp(log_Zspike - log_Z_norm) +
		-d_sigmoid_dz * sigmoid(-logit_p_omega_old) * sigmoid(logit_p_gamma_old) * exp(log_ZSB - log_Z_norm) +
		-d_sigmoid_dz * sigmoid(-logit_p_omega_old) * sigmoid(-logit_p_gamma_old) * exp(log_Zspike - log_Z_norm) + 
		exp(logit_p_z_old - log_norm_z)

	c1_p_z <- log(sigmoid(logit_p_eta_old) * exp(log_ZSB - max) + sigmoid(-logit_p_eta_old) * exp(log_Zspike - max)) + max
        c0_p_z <- log(sigmoid(logit_p_omega_old) * sigmoid(logit_p_tau_old) * exp(log_ZSB - max) +
                        sigmoid(logit_p_omega_old) * sigmoid(-logit_p_tau_old) * exp(log_Zspike - max) +
                        sigmoid(-logit_p_omega_old) * sigmoid(logit_p_gamma_old) * exp(log_ZSB - max) +
                        sigmoid(-logit_p_omega_old) * sigmoid(-logit_p_gamma_old) * exp(log_Zspike - max)) + max

        logit_p_z_new <- logit_p_z_old + c1_p_z - c0_p_z

	## omega latent variables

	d_sigmoid_domega <- sigmoid(logit_p_omega_old) * (1 - sigmoid(logit_p_omega_old))
		
	d_log_Z_domega <- sigmoid(-logit_p_z_old) * d_sigmoid_domega * sigmoid(logit_p_tau_old) * exp(log_ZSB - log_Z_norm) +
		sigmoid(-logit_p_z_old) * d_sigmoid_domega * sigmoid(-logit_p_tau_old) * exp(log_Zspike - log_Z_norm) +
		sigmoid(-logit_p_z_old) * -d_sigmoid_domega * sigmoid(logit_p_gamma_old) * exp(log_ZSB - log_Z_norm) +
		sigmoid(-logit_p_z_old) * -d_sigmoid_domega * sigmoid(-logit_p_gamma_old) * exp(log_Zspike - log_Z_norm) + 
		exp(logit_p_omega_old - log_norm_omega) 

	c1_p_omega <- log(sigmoid(logit_p_z_old) * sigmoid(logit_p_eta_old) * exp(log_ZSB - max) +
                sigmoid(logit_p_z_old) * sigmoid(-logit_p_eta_old) * exp(log_Zspike - max) +
                sigmoid(-logit_p_z_old) * sigmoid(logit_p_tau_old) * exp(log_ZSB - max) +
                sigmoid(-logit_p_z_old) * sigmoid(-logit_p_tau_old) * exp(log_Zspike - max)) + max
        c0_p_omega <- log(sigmoid(logit_p_z_old) * sigmoid(logit_p_eta_old) * exp(log_ZSB - max) +
                sigmoid(logit_p_z_old) * sigmoid(-logit_p_eta_old) * exp(log_Zspike - max) +
                sigmoid(-logit_p_z_old) * sigmoid(logit_p_gamma_old) * exp(log_ZSB - max) +
                sigmoid(-logit_p_z_old) * sigmoid(-logit_p_gamma_old) * exp(log_Zspike - max)) + max

        logit_p_omega_new <- logit_p_omega_old + c1_p_omega - c0_p_omega

	## gamma latent variables

	d_sigmoid_dgamma <- sigmoid(logit_p_gamma_old) * (1 - sigmoid(logit_p_gamma_old))

	d_log_Z_dgamma <- sigmoid(-logit_p_z_old) * sigmoid(-logit_p_omega_old) * d_sigmoid_dgamma * exp(log_ZSB - log_Z_norm) +
		sigmoid(-logit_p_z_old) * sigmoid(-logit_p_omega_old) * -d_sigmoid_dgamma * exp(log_Zspike - log_Z_norm) + 
		exp(logit_p_gamma_old - log_norm_gamma) 

	c1_p_gamma <- log(sigmoid(logit_p_z_old) * sigmoid(logit_p_eta_old) * exp(log_ZSB - max) +
                sigmoid(logit_p_z_old) * sigmoid(-logit_p_eta_old) * exp(log_Zspike - max) +
                sigmoid(-logit_p_z_old) * sigmoid(logit_p_omega_old) * sigmoid(logit_p_tau_old) * exp(log_ZSB - max) +
                sigmoid(-logit_p_z_old) * sigmoid(logit_p_omega_old) * sigmoid(-logit_p_tau_old) * exp(log_Zspike - max) +
                sigmoid(-logit_p_z_old) * sigmoid(-logit_p_omega_old) * exp(log_ZSB - max)) + max
        c0_p_gamma <- log(sigmoid(logit_p_z_old) * sigmoid(logit_p_eta_old) * exp(log_ZSB - max) +
                sigmoid(logit_p_z_old) * sigmoid(-logit_p_eta_old) * exp(log_Zspike - max) +
                sigmoid(-logit_p_z_old) * sigmoid(logit_p_omega_old) * sigmoid(logit_p_tau_old) * exp(log_ZSB - max) +
                sigmoid(-logit_p_z_old) * sigmoid(logit_p_omega_old) * sigmoid(-logit_p_tau_old) * exp(log_Zspike - max) +
                sigmoid(-logit_p_z_old) * sigmoid(-logit_p_omega_old) * exp(log_Zspike - max)) + max

        logit_p_gamma_new <- logit_p_gamma_old + c1_p_gamma - c0_p_gamma

	## tau latent variables

	d_sigmoid_dtau <- sigmoid(logit_p_tau_old) * (1 - sigmoid(logit_p_tau_old))

	d_log_Z_dtau <- sigmoid(-logit_p_z_old) * sigmoid(logit_p_omega_old) * d_sigmoid_dtau * exp(log_ZSB - log_Z_norm) +
		sigmoid(-logit_p_z_old) * sigmoid(logit_p_omega_old) * -d_sigmoid_dtau * exp(log_Zspike - log_Z_norm) + 
		exp(logit_p_tau_old - log_norm_tau) 

	c1_p_tau <- log(sigmoid(logit_p_z_old) * sigmoid(logit_p_eta_old) * exp(log_ZSB - max) +
                sigmoid(logit_p_z_old) * sigmoid(-logit_p_eta_old) * exp(log_Zspike - max) +
                sigmoid(-logit_p_z_old) * sigmoid(logit_p_omega_old) * exp(log_ZSB - max) +
                sigmoid(-logit_p_z_old) * sigmoid(-logit_p_omega_old) * sigmoid(logit_p_gamma_old) * exp(log_ZSB - max) +
                sigmoid(-logit_p_z_old) * sigmoid(-logit_p_omega_old) * sigmoid(-logit_p_gamma_old) * exp(log_Zspike - max)) + max

        c0_p_tau <- log(sigmoid(logit_p_z_old) * sigmoid(logit_p_eta_old) * exp(log_ZSB - max) +
                sigmoid(logit_p_z_old) * sigmoid(-logit_p_eta_old) * exp(log_Zspike - max) +
                sigmoid(-logit_p_z_old) * sigmoid(logit_p_omega_old) * exp(log_Zspike - max) +
                sigmoid(-logit_p_z_old) * sigmoid(-logit_p_omega_old) * sigmoid(logit_p_gamma_old) * exp(log_ZSB - max) +
                sigmoid(-logit_p_z_old) * sigmoid(-logit_p_omega_old) * sigmoid(-logit_p_gamma_old) * exp(log_Zspike - max)) + max

        logit_p_tau_new <- logit_p_tau_old + c1_p_tau - c0_p_tau

	## eta latent variables

	d_sigmoid_deta <- sigmoid(logit_p_eta_old) * (1 - sigmoid(logit_p_eta_old))

	d_log_Z_deta <- sigmoid(logit_p_z_old) * d_sigmoid_deta * exp(log_ZSB - log_Z_norm) +
		sigmoid(logit_p_z_old) * -d_sigmoid_deta * exp(log_Zspike - log_Z_norm) +
		exp(logit_p_eta_old - log_norm_eta) 

	c1_p_eta <- log(sigmoid(logit_p_z_old) * exp(log_ZSB - max) +
                sigmoid(-logit_p_z_old) * sigmoid(logit_p_omega_old) * sigmoid(logit_p_tau_old) * exp(log_ZSB - max) +
                sigmoid(-logit_p_z_old) * sigmoid(logit_p_omega_old) * sigmoid(-logit_p_tau_old) * exp(log_Zspike - max) +
                sigmoid(-logit_p_z_old) * sigmoid(-logit_p_omega_old) * sigmoid(logit_p_gamma_old) * exp(log_ZSB - max) +
                sigmoid(-logit_p_z_old) * sigmoid(-logit_p_omega_old) * sigmoid(-logit_p_gamma_old) * exp(log_Zspike - max)) + max

        c0_p_eta <- log(sigmoid(logit_p_z_old) * exp(log_Zspike - max) +
                sigmoid(-logit_p_z_old) * sigmoid(logit_p_omega_old) * sigmoid(logit_p_tau_old) * exp(log_ZSB - max) +
                sigmoid(-logit_p_z_old) * sigmoid(logit_p_omega_old) * sigmoid(-logit_p_tau_old) * exp(log_Zspike - max) +
                sigmoid(-logit_p_z_old) * sigmoid(-logit_p_omega_old) * sigmoid(logit_p_gamma_old) * exp(log_ZSB - max) +
                sigmoid(-logit_p_z_old) * sigmoid(-logit_p_omega_old) * sigmoid(-logit_p_gamma_old) * exp(log_Zspike - max)) + max 

        logit_p_eta_new <- logit_p_eta_old + c1_p_eta - c0_p_eta

	## We compute the new approximate factors updates 

	old_nuTilde <- a$gTildes$nuTilde[ indx ]
	new_nuTilde <- var_new^-1 - v_old

	old_muTilde <- a$gTildes$muTilde[ indx ]
	new_muTilde <- (mean_new / var_new - m_old)

	old_zTilde <- a$gTildes$zTilde[ indx ]
	new_zTilde <- logit_p_z_new - logit_p_z_old

	old_gammaTilde <- a$gTildes$gammaTilde[ indx ]
	new_gammaTilde <- logit_p_gamma_new - logit_p_gamma_old

	old_omegaTilde <- a$gTildes$omegaTilde[ indx ]
	new_omegaTilde <- logit_p_omega_new - logit_p_omega_old

	old_tauTilde <- a$gTildes$tauTilde[ indx ]
	new_tauTilde <- logit_p_tau_new - logit_p_tau_old

	old_etaTilde <- a$gTildes$etaTilde[ indx ]
	new_etaTilde <- logit_p_eta_new - logit_p_eta_old

	a$gTildes$nuTilde[ indx ] <- damping * new_nuTilde + (1 - damping) * old_nuTilde  
	a$gTildes$muTilde[ indx ] <- damping * new_muTilde + (1 - damping) * old_muTilde
	a$gTildes$zTilde[ indx ] <- damping * new_zTilde + (1 - damping) * old_zTilde
	a$gTildes$omegaTilde[ indx ] <- damping * new_omegaTilde + (1 - damping) * old_omegaTilde
	a$gTildes$gammaTilde[ indx ] <- damping * new_gammaTilde + (1 - damping) * old_gammaTilde
	a$gTildes$tauTilde[ indx ] <- damping * new_tauTilde + (1 - damping) * old_tauTilde
	a$gTildes$etaTilde[ indx ] <- damping * new_etaTilde + (1 - damping) * old_etaTilde

	max_z <- pmax(0, logit_p_z_new)
	log_norm_z <- log(exp(- max_z) + exp(logit_p_z_new - max_z)) + max_z
	max_omega <- pmax(0, logit_p_omega_new)
	log_norm_omega <- log(exp(- max_omega) + exp(logit_p_omega_new - max_omega)) + max_omega
	max_gamma <- pmax(0, logit_p_gamma_new)
	log_norm_gamma <- log(exp(- max_gamma) + exp(logit_p_gamma_new - max_gamma)) + max_gamma
	max_tau <- pmax(0, logit_p_tau_new)
	log_norm_tau <- log(exp(- max_tau) + exp(logit_p_tau_new - max_tau)) + max_tau
	max_eta <- pmax(0, logit_p_eta_new)
	log_norm_eta <- log(exp(- max_eta) + exp(logit_p_eta_new - max_eta)) + max_eta

	a$gTildes$sTilde[ indx ] <- log_Z - log_norm_z - log_norm_omega - log_norm_gamma - log_norm_tau - log_norm_eta - 
		0.5 * log(2 * pi * var_new) - 0.5 * (mean_new^2 / var_new)

	# If it is a classificaiton problem we only update the Gaussian part of the bias

	if (a$class == TRUE) {

		updated <- which(indx[ 1 : a$nTasks, 1 ])

		a$gTildes$sTilde[ updated, 1 ] <- log_ZSB[ updated ] - 0.5 * log(2 * pi * var_new[ updated ]) - 
			0.5 * (mean_new[ updated ]^2 / var_new[ updated ])

		a$gTildes$zTilde[ , 1 ] <- 0
		a$gTildes$omegaTilde[ , 1 ] <- 0
		a$gTildes$gammaTilde[ , 1 ] <- 0
		a$gTildes$tauTilde[ , 1 ] <- 0
		a$gTildes$etaTilde[ , 1 ] <- 0
	}

	a	
}

##
# Function: process_prior_binary_latent_variables
#
# Description: process the terms of the prior
#
# Arguments: 
#		q -> reconstructed posterior
#		a -> posterior approximation
#		damping -> Damping factor to improve convergence. 
#
# Returns: 	The posterior approximation
#

process_prior_binary_latent_variables <- function(q, a, damping) {

	# First we compute an old posterior distribution

	logit_p_z_old <- q$logit_p_z - a$hTildes_z$logit_zTilde
	logit_p_omega_old <- q$logit_p_omega - a$hTildes_omega$logit_omegaTilde
	logit_p_gamma_old <- q$logit_p_gamma - a$hTildes_gamma$logit_gammaTilde
	logit_p_tau_old <- q$logit_p_tau - a$hTildes_tau$logit_tauTilde
	logit_p_eta_old <- q$logit_p_eta - a$hTildes_eta$logit_etaTilde

	a_z_old <- q$a_z - a$hTildes_z$a_zTilde
	b_z_old <- q$b_z - a$hTildes_z$a_zTilde
	a_omega_old <- q$a_omega - a$hTildes_omega$a_omegaTilde
	b_omega_old <- q$b_omega - a$hTildes_omega$b_omegaTilde
	a_gamma_old <- q$a_gamma - a$hTildes_gamma$a_gammaTilde
	b_gamma_old <- q$b_gamma - a$hTildes_gamma$b_gammaTilde
	a_tau_old <- q$a_tau - a$hTildes_tau$a_tauTilde
	b_tau_old <- q$b_tau - a$hTildes_tau$b_tauTilde
	a_eta_old <- q$a_eta - a$hTildes_eta$a_etaTilde
	b_eta_old <- q$b_eta - a$hTildes_eta$b_etaTilde

	indx_z <- a_z_old > -1 & b_z_old > -1 
	indx_omega <- a_omega_old > -1 & b_omega_old > -1 
	indx_gamma <- a_gamma_old > -1 & b_gamma_old > -1 
	indx_tau <- a_tau_old > -1 & b_tau_old > -1 
	indx_eta <- a_eta_old > -1 & b_eta_old > -1 

	a_z_old <- a_z_old[ indx_z ]; b_z_old <- b_z_old[ indx_z ]; logit_p_z_old <- logit_p_z_old[ indx_z ]
	a_omega_old <- a_omega_old[ indx_omega ]; b_omega_old <- b_omega_old[ indx_omega ]; logit_p_omega_old <- logit_p_omega_old[ indx_omega ]
	a_gamma_old <- a_gamma_old[ indx_gamma ]; b_gamma_old <- b_gamma_old[ indx_gamma ]; logit_p_gamma_old <- logit_p_gamma_old[ indx_gamma ]
	a_tau_old <- a_tau_old[ indx_tau ]; b_tau_old <- b_tau_old[ indx_tau ]; logit_p_tau_old <- logit_p_tau_old[ indx_tau ]
	a_eta_old <- a_eta_old[ indx_eta ]; b_eta_old <- b_eta_old[ indx_eta ]; logit_p_eta_old <- logit_p_eta_old[ indx_eta ]

	log_Zbeta_p_z <- log_Zbeta_p(a_z_old, b_z_old)
	log_Zbeta_1mp_z <- log_Zbeta_1mp(a_z_old, b_z_old)
	log_Zbeta_p_omega <- log_Zbeta_p(a_omega_old, b_omega_old)
	log_Zbeta_1mp_omega <- log_Zbeta_1mp(a_omega_old, b_omega_old)
	log_Zbeta_p_gamma <- log_Zbeta_p(a_gamma_old, b_gamma_old)
	log_Zbeta_1mp_gamma <- log_Zbeta_1mp(a_gamma_old, b_gamma_old)
	log_Zbeta_p_tau <- log_Zbeta_p(a_tau_old, b_tau_old)
	log_Zbeta_1mp_tau <- log_Zbeta_1mp(a_tau_old, b_tau_old)
	log_Zbeta_p_eta <- log_Zbeta_p(a_eta_old, b_eta_old)
	log_Zbeta_1mp_eta <- log_Zbeta_1mp(a_eta_old, b_eta_old)

	# We compute the log of the normalization constant

	max_z <- pmax(logit_p_z_old + log_Zbeta_p_z, log_Zbeta_1mp_z)
	log_Z_z <- log(exp(logit_p_z_old + log_Zbeta_p_z - max_z) + exp(log_Zbeta_1mp_z - max_z)) + max_z
	max_omega <- pmax(logit_p_omega_old + log_Zbeta_p_omega, log_Zbeta_1mp_omega)
	log_Z_omega <- log(exp(logit_p_omega_old + log_Zbeta_p_omega - max_omega) + exp(log_Zbeta_1mp_omega - max_omega)) + max_omega
	max_gamma <- pmax(logit_p_gamma_old + log_Zbeta_p_gamma, log_Zbeta_1mp_gamma)
	log_Z_gamma <- log(exp(logit_p_gamma_old + log_Zbeta_p_gamma - max_gamma) + exp(log_Zbeta_1mp_gamma - max_gamma)) + max_gamma
	max_tau <- pmax(logit_p_tau_old + log_Zbeta_p_tau, log_Zbeta_1mp_tau)
	log_Z_tau <- log(exp(logit_p_tau_old + log_Zbeta_p_tau - max_tau) + exp(log_Zbeta_1mp_tau - max_tau)) + max_tau
	max_eta <- pmax(logit_p_eta_old + log_Zbeta_p_eta, log_Zbeta_1mp_eta)
	log_Z_eta <- log(exp(logit_p_eta_old + log_Zbeta_p_eta - max_eta) + exp(log_Zbeta_1mp_eta - max_eta)) + max_eta

	# We compute the updated posterior for the binary latent variables

	dlog_Z_z_d_logit_p_z <- exp(logit_p_z_old + log_Zbeta_p_z - log_Z_z)
	dlog_Z_omega_d_logit_p_omega <- exp(logit_p_omega_old + log_Zbeta_p_omega - log_Z_omega)
	dlog_Z_gamma_d_logit_p_gamma <- exp(logit_p_gamma_old + log_Zbeta_p_gamma - log_Z_gamma)
	dlog_Z_tau_d_logit_p_tau <- exp(logit_p_tau_old + log_Zbeta_p_tau - log_Z_tau)
	dlog_Z_eta_d_logit_p_eta <- exp(logit_p_eta_old + log_Zbeta_p_eta - log_Z_eta)

#	logit_p_z_new <- logit(dlog_Z_z_d_logit_p_z)
#	logit_p_omega_new <- logit(dlog_Z_omega_d_logit_p_omega)
#	logit_p_gamma_new <- logit(dlog_Z_gamma_d_logit_p_gamma)
#	logit_p_tau_new <- logit(dlog_Z_tau_d_logit_p_tau)
#	logit_p_eta_new <- logit(dlog_Z_eta_d_logit_p_eta)

	logit_p_z_new <- logit_p_z_old + log_Zbeta_p_z - log_Zbeta_1mp_z
	logit_p_omega_new <- logit_p_omega_old + log_Zbeta_p_omega - log_Zbeta_1mp_omega
	logit_p_gamma_new <- logit_p_gamma_old + log_Zbeta_p_gamma - log_Zbeta_1mp_gamma
	logit_p_tau_new <- logit_p_tau_old + log_Zbeta_p_tau - log_Zbeta_1mp_tau
	logit_p_eta_new <- logit_p_eta_old + log_Zbeta_p_eta - log_Zbeta_1mp_eta

	# We compute the first and second moment for each beta distribution

	e1_z <- exp(logit_p_z_old - log_Z_z + log_Zbeta_p2(a_z_old, b_z_old)) + exp(- log_Z_z + log_Zbeta_1mp_p(a_z_old, b_z_old))
	e2_z <- exp(logit_p_z_old - log_Z_z + log_Zbeta_p3(a_z_old, b_z_old)) + exp(- log_Z_z + log_Zbeta_1mp_p2(a_z_old, b_z_old))
		
	e1_omega <- exp(logit_p_omega_old - log_Z_omega + log_Zbeta_p2(a_omega_old, b_omega_old)) + 
		exp(- log_Z_omega + log_Zbeta_1mp_p(a_omega_old, b_omega_old))
	e2_omega <- exp(logit_p_omega_old - log_Z_omega + log_Zbeta_p3(a_omega_old, b_omega_old)) + 
		exp(- log_Z_omega + log_Zbeta_1mp_p2(a_omega_old, b_omega_old))

	e1_gamma <- exp(logit_p_gamma_old - log_Z_gamma + log_Zbeta_p2(a_gamma_old, b_gamma_old)) + 
		exp(- log_Z_gamma + log_Zbeta_1mp_p(a_gamma_old, b_gamma_old))
	e2_gamma <- exp(logit_p_gamma_old - log_Z_gamma + log_Zbeta_p3(a_gamma_old, b_gamma_old)) + 
		exp(- log_Z_gamma + log_Zbeta_1mp_p2(a_gamma_old, b_gamma_old))

	e1_tau <- exp(logit_p_tau_old - log_Z_tau + log_Zbeta_p2(a_tau_old, b_tau_old)) + 
		exp(- log_Z_tau + log_Zbeta_1mp_p(a_tau_old, b_tau_old))
	e2_tau <- exp(logit_p_tau_old - log_Z_tau + log_Zbeta_p3(a_tau_old, b_tau_old)) + 
		exp(- log_Z_tau + log_Zbeta_1mp_p2(a_tau_old, b_tau_old))
	
	e1_eta <- exp(logit_p_eta_old - log_Z_eta + log_Zbeta_p2(a_eta_old, b_eta_old)) + 
		exp(- log_Z_eta + log_Zbeta_1mp_p(a_eta_old, b_eta_old))
	e2_eta <- exp(logit_p_eta_old - log_Z_eta + log_Zbeta_p3(a_eta_old, b_eta_old)) + 
		exp(- log_Z_eta + log_Zbeta_1mp_p2(a_eta_old, b_eta_old))

	# We compute the parameters of the updated posterior

	a_z_new <- e1_z * (e1_z - e2_z) / (e2_z - e1_z^2) - 1
	b_z_new <- (1 - e1_z) * (e1_z - e2_z) / (e2_z - e1_z^2) - 1

	a_omega_new <- e1_omega * (e1_omega - e2_omega) / (e2_omega - e1_omega^2) - 1
	b_omega_new <- (1 - e1_omega) * (e1_omega - e2_omega) / (e2_omega - e1_omega^2) - 1

	a_gamma_new <- e1_gamma * (e1_gamma - e2_gamma) / (e2_gamma - e1_gamma^2) - 1
	b_gamma_new <- (1 - e1_gamma) * (e1_gamma - e2_gamma) / (e2_gamma - e1_gamma^2) - 1

	a_tau_new <- e1_tau * (e1_tau - e2_tau) / (e2_tau - e1_tau^2) - 1
	b_tau_new <- (1 - e1_tau) * (e1_tau - e2_tau) / (e2_tau - e1_tau^2) - 1

	a_eta_new <- e1_eta * (e1_eta - e2_eta) / (e2_eta - e1_eta^2) - 1
	b_eta_new <- (1 - e1_eta) * (e1_eta - e2_eta) / (e2_eta - e1_eta^2) - 1

	# We compute the parameters of the updated approximate factor and the old ones

	new_logit_zTilde <- logit_p_z_new - logit_p_z_old
	new_logit_omegaTilde <- logit_p_omega_new - logit_p_omega_old
	new_logit_gammaTilde <- logit_p_gamma_new - logit_p_gamma_old
	new_logit_tauTilde <- logit_p_tau_new - logit_p_tau_old
	new_logit_etaTilde <- logit_p_eta_new - logit_p_eta_old

	old_logit_zTilde <- a$hTildes_z$logit_zTilde[ indx_z ]
	old_logit_omegaTilde <- a$hTildes_omega$logit_omegaTilde[ indx_omega ]
	old_logit_gammaTilde <- a$hTildes_gamma$logit_gammaTilde[ indx_gamma ]
	old_logit_tauTilde <- a$hTildes_tau$logit_tauTilde[ indx_tau ]
	old_logit_etaTilde <- a$hTildes_eta$logit_etaTilde[ indx_eta ]

	new_a_zTilde <- a_z_new - a_z_old; new_b_zTilde <- b_z_new - b_z_old
	new_a_omegaTilde <- a_omega_new - a_omega_old; new_b_omegaTilde <- b_omega_new - b_omega_old
	new_a_gammaTilde <- a_gamma_new - a_gamma_old; new_b_gammaTilde <- b_gamma_new - b_gamma_old
	new_a_tauTilde <- a_tau_new - a_tau_old; new_b_tauTilde <- b_tau_new - b_tau_old
	new_a_etaTilde <- a_eta_new - a_eta_old; new_b_etaTilde <- b_eta_new - b_eta_old

	old_a_zTilde <- a$hTildes_z$a_zTilde[ indx_z ]; old_b_zTilde <- a$hTildes_z$b_zTilde[ indx_z ]
	old_a_omegaTilde <- a$hTildes_omega$a_omegaTilde[ indx_omega ]; old_b_omegaTilde <- a$hTildes_omega$b_omegaTilde[ indx_omega ]
	old_a_gammaTilde <- a$hTildes_gamma$a_gammaTilde[ indx_gamma ]; old_b_gammaTilde <- a$hTildes_gamma$b_gammaTilde[ indx_gamma ]
	old_a_tauTilde <- a$hTildes_tau$a_tauTilde[ indx_tau ]; old_b_tauTilde <- a$hTildes_tau$b_tauTilde[ indx_tau ]
	old_a_etaTilde <- a$hTildes_eta$a_etaTilde[ indx_eta ]; old_b_etaTilde <- a$hTildes_eta$b_etaTilde[ indx_eta ]

	# We do the actual update

	a$hTildes_z$a_zTilde[ indx_z ] <- damping * new_a_zTilde + (1 - damping) * old_a_zTilde
	a$hTildes_omega$a_omegaTilde[ indx_omega ] <- damping * new_a_omegaTilde + (1 - damping) * old_a_omegaTilde
	a$hTildes_gamma$a_gammaTilde[ indx_gamma ] <- damping * new_a_gammaTilde + (1 - damping) * old_a_gammaTilde
	a$hTildes_tau$a_tauTilde[ indx_tau ] <- damping * new_a_tauTilde + (1 - damping) * old_a_tauTilde
	a$hTildes_eta$a_etaTilde[ indx_eta ] <- damping * new_a_etaTilde + (1 - damping) * old_a_etaTilde

	a$hTildes_z$b_zTilde[ indx_z ] <- damping * new_b_zTilde + (1 - damping) * old_b_zTilde
	a$hTildes_omega$b_omegaTilde[ indx_omega ] <- damping * new_b_omegaTilde + (1 - damping) * old_b_omegaTilde
	a$hTildes_gamma$b_gammaTilde[ indx_gamma ] <- damping * new_b_gammaTilde + (1 - damping) * old_b_gammaTilde
	a$hTildes_tau$b_tauTilde[ indx_tau ] <- damping * new_b_tauTilde + (1 - damping) * old_b_tauTilde
	a$hTildes_eta$b_etaTilde[ indx_eta ] <- damping * new_b_etaTilde + (1 - damping) * old_b_etaTilde

	a$hTildes_z$logit_zTilde[ indx_z ] <- damping * new_logit_zTilde + (1 - damping) * old_logit_zTilde
	a$hTildes_omega$logit_omegaTilde[ indx_omega ] <- damping * new_logit_omegaTilde + (1 - damping) * old_logit_omegaTilde
	a$hTildes_gamma$logit_gammaTilde[ indx_gamma ] <- damping * new_logit_gammaTilde + (1 - damping) * old_logit_gammaTilde
	a$hTildes_tau$logit_tauTilde[ indx_tau ] <- damping * new_logit_tauTilde + (1 - damping) * old_logit_tauTilde
	a$hTildes_eta$logit_etaTilde[ indx_eta ] <- damping * new_logit_etaTilde + (1 - damping) * old_logit_etaTilde

	# We compute the normalization constants

	max_z <- pmax(0, logit_p_z_new)
	log_norm_z <- log(exp(- max_z) + exp(logit_p_z_new - max_z)) + max_z
	max_omega <- pmax(0, logit_p_omega_new)
	log_norm_omega <- log(exp(- max_omega) + exp(logit_p_omega_new - max_omega)) + max_omega
	max_gamma <- pmax(0, logit_p_gamma_new)
	log_norm_gamma <- log(exp(- max_gamma) + exp(logit_p_gamma_new - max_gamma)) + max_gamma
	max_tau <- pmax(0, logit_p_tau_new)
	log_norm_tau <- log(exp(- max_tau) + exp(logit_p_tau_new - max_tau)) + max_tau
	max_eta <- pmax(0, logit_p_eta_new)
	log_norm_eta <- log(exp(- max_eta) + exp(logit_p_eta_new - max_eta)) + max_eta

	a$hTildes_z$s_zTilde[ indx_z ] <- log_Z_z - log_norm_z - lbeta(a_z_new + 1, b_z_new + 1)
	a$hTildes_omega$s_omegaTilde[ indx_omega ] <- log_Z_omega - log_norm_omega - lbeta(a_omega_new + 1, b_omega_new + 1)
	a$hTildes_gamma$s_gammaTilde[ indx_gamma ] <- log_Z_gamma - log_norm_gamma - lbeta(a_gamma_new + 1, b_gamma_new + 1)
	a$hTildes_tau$s_tauTilde[ indx_tau ] <- log_Z_tau - log_norm_tau - lbeta(a_tau_new + 1, b_tau_new + 1)
	a$hTildes_eta$s_etaTilde[ indx_eta ] <- log_Z_eta - log_norm_eta - lbeta(a_eta_new + 1, b_eta_new + 1)

	# If it is a classificaiton problem we do not update the prior for the bias

	if (a$class == TRUE) {

		a$hTildes_z$s_zTilde[ 1 ] <- 0
		a$hTildes_z$a_zTilde[ 1 ] <- 0
		a$hTildes_z$b_zTilde[ 1 ] <- 0
		a$hTildes_z$logit_zTilde[ 1 ] <- 0

		a$hTildes_gamma$s_gammaTilde[ 1 ] <- 0
		a$hTildes_gamma$a_gammaTilde[ 1 ] <- 0
		a$hTildes_gamma$b_gammaTilde[ 1 ] <- 0
		a$hTildes_gamma$logit_gammaTilde[ 1 ] <- 0

		a$hTildes_tau$s_tauTilde[ ,1 ] <- 0
		a$hTildes_tau$a_tauTilde[ ,1 ] <- 0
		a$hTildes_tau$b_tauTilde[ ,1 ] <- 0
		a$hTildes_tau$logit_tauTilde[ ,1 ] <- 0

		a$hTildes_eta$s_etaTilde[ ,1 ] <- 0
		a$hTildes_eta$a_etaTilde[ ,1 ] <- 0
		a$hTildes_eta$b_etaTilde[ ,1 ] <- 0
		a$hTildes_eta$logit_etaTilde[ ,1 ] <- 0
	}

	a
}

##
# Function: check_convergence
#
# Description: looks for convergence in the EP algorithm
#
# Arguments: 
#		aNew -> posterior approximation 
#		aOld -> posterior approximation
#
# Returns: 	A boolean indicating convergence
#

check_convergence <- function(aNew, aOld, verbose = FALSE, damping) {

	# We evaluate the maximum change within the posterior approximation

	maxChange <- 0

	for (k in 1 : aNew$nTasks) {
		maxChange <- max(maxChange, abs(aNew$fTildes$mTilde[[ k ]] - aOld$fTildes$mTilde[[ k ]]))
		maxChange <- max(maxChange, pmin(abs(aNew$fTildes$vTilde[[ k ]]^-1 - aOld$fTildes$vTilde[[ k ]]^-1),
				abs(aNew$fTildes$vTilde[[ k ]] - aOld$fTildes$vTilde[[ k ]])))
	}

	maxChange <- max(maxChange, abs(aNew$gTildes$muTilde - aOld$gTildes$muTilde))
	maxChange <- max(maxChange, abs(aNew$gTildes$nuTilde^-1 - aOld$gTildes$nuTilde^-1))
	maxChange <- max(maxChange, abs(aNew$gTildes$zTilde - aOld$gTildes$zTilde))
	maxChange <- max(maxChange, abs(aNew$gTildes$omegaTilde - aOld$gTildes$omegaTilde))
	maxChange <- max(maxChange, abs(aNew$gTildes$gammaTilde - aOld$gTildes$gammaTilde))
	maxChange <- max(maxChange, abs(aNew$gTildes$tauTilde - aOld$gTildes$tauTilde))
	maxChange <- max(maxChange, abs(aNew$gTildes$etaTilde - aOld$gTildes$etaTilde))
	maxChange <- max(maxChange, abs(aNew$hTildes_z$logit_zTilde - aOld$hTildes_z$logit_zTilde))
	maxChange <- max(maxChange, abs(aNew$hTildes_omega$logit_omegaTilde - aOld$hTildes_omega$logit_omegaTilde))
	maxChange <- max(maxChange, abs(aNew$hTildes_gamma$logit_gammaTilde - aOld$hTildes_gamma$logit_gammaTilde))
	maxChange <- max(maxChange, abs(aNew$hTildes_tau$logit_tauTilde - aOld$hTildes_tau$logit_tauTilde))
	maxChange <- max(maxChange, abs(aNew$hTildes_eta$logit_etaTilde - aOld$hTildes_eta$logit_etaTilde))
	maxChange <- max(maxChange, abs(aNew$hTildes_z$a_zTilde - aOld$hTildes_z$a_zTilde))
	maxChange <- max(maxChange, abs(aNew$hTildes_omega$a_omegaTilde - aOld$hTildes_omega$a_omegaTilde))
	maxChange <- max(maxChange, abs(aNew$hTildes_gamma$a_gammaTilde - aOld$hTildes_gamma$a_gammaTilde))
	maxChange <- max(maxChange, abs(aNew$hTildes_tau$a_tauTilde - aOld$hTildes_tau$a_tauTilde))
	maxChange <- max(maxChange, abs(aNew$hTildes_eta$a_etaTilde - aOld$hTildes_eta$a_etaTilde))
	maxChange <- max(maxChange, abs(aNew$hTildes_z$b_zTilde - aOld$hTildes_z$b_zTilde))
	maxChange <- max(maxChange, abs(aNew$hTildes_omega$b_omegaTilde - aOld$hTildes_omega$b_omegaTilde))
	maxChange <- max(maxChange, abs(aNew$hTildes_gamma$b_gammaTilde - aOld$hTildes_gamma$b_gammaTilde))
	maxChange <- max(maxChange, abs(aNew$hTildes_tau$b_tauTilde - aOld$hTildes_tau$b_tauTilde))
	maxChange <- max(maxChange, abs(aNew$hTildes_eta$b_etaTilde - aOld$hTildes_eta$b_etaTilde))

	if (verbose)
		cat("Damping:", damping, "EP: max change", maxChange, "\n")

	if (maxChange < 1e-4)
		TRUE
	else
		FALSE
}

##
# Function: check_convergence_q
#
# Description: looks for convergence in the EP algorithm
#
# Arguments: 
#		qNew -> posterior approximation 
#		qOld -> posterior approximation
#
# Returns: 	A boolean indicating convergence
#

check_convergence_q <- function(qNew, qOld, verbose = FALSE, damping) {

	# We evaluate the maximum change within the posterior approximation

	maxChange <- 0

	maxChange <- max(maxChange, abs(qNew$m_w - qOld$m_w))
	maxChange <- max(maxChange, abs(qNew$v_w - qOld$v_w))
	maxChange <- max(maxChange, abs(qNew$logit_p_z - qOld$logit_p_z))
	maxChange <- max(maxChange, abs(qNew$logit_p_omega - qOld$logit_p_omega))
	maxChange <- max(maxChange, abs(qNew$logit_p_gamma - qOld$logit_p_gamma))
	maxChange <- max(maxChange, abs(qNew$logit_p_tau - qOld$logit_p_tau))
	maxChange <- max(maxChange, abs(qNew$logit_p_eta - qOld$logit_p_eta))
	maxChange <- max(maxChange, abs(qNew$alphaNoise - qOld$alphaNoise))
	maxChange <- max(maxChange, abs(qNew$betaNoise - qOld$betaNoise))

	for (k in 1 : length(qNew$m_targets)) {
		maxChange <- max(maxChange, abs(qNew$m_targets[[ k ]] - qOld$m_targets[[ k ]]))
		maxChange <- max(maxChange, abs(qNew$v_targets[[ k ]]^-1 - qOld$v_targets[[ k ]]^-1))

		maxChange <- max(maxChange, abs(qNew$m_targets_delta[[ k ]] - qOld$m_targets_delta[[ k ]]))
		maxChange <- max(maxChange, abs(qNew$v_targets_delta[[ k ]] - qOld$v_targets_delta[[ k ]]))
	}

	if (verbose)
		cat("Damping:", damping, "EP: max change", maxChange, "\n")

	if (maxChange < 1e-3)
		TRUE
	else
		FALSE
}


##
# Function: evaluate_evidence
#
# Description: evaluates the models evidence provided by the EP algorithm
#
# Arguments: 
#		a -> posterior approximation
#		class -> A boolean which indicates binary classification or regression 
#
# Returns: 	Log evidence of the model
#

evaluate_evidence <- function(a, class) {

	log_Z <- 0

	q <- compute_titled_distribution(a)

        # We compute the constant that results from the multiplication of the approximate factors corresponding to the
	# likelihood for classification with the Gaussian prior

	if (a$n_cores != 1) {

		result <- foreach (k = 1 : a$nTasks) %dopar% {
	
			r_log_Z <- 0

			n <- nrow(a$X[[ k ]])
			d <- a$d
	
			tX <- t.default(a$X[[ k ]])
			dX <- matrix(a$gTildes$nuTilde[ k, ]^-1, n, d, byrow = TRUE) * a$X[[ k ]]
	
			sLikelihood <- sum(a$fTildes$cTilde[[ k ]])
	
			r_log_Z <- r_log_Z + sLikelihood + sum(a$gTildes$sTilde[ k , ])
	
			r_log_Z <- r_log_Z + d / 2 * log(2 * pi)
	
			r_log_Z <- r_log_Z - 0.5 * (determinant(diag(n) + diag(1 / q$v_targets[[ k ]]) %*% a$X[[ k ]] %*% 
				t.default(dX))$modulus[[1]] + sum(log(abs(a$gTildes$nuTilde[ k, ]))))
	
			v_aux <- c((q$m_targets[[ k ]] / q$v_targets[[ k ]]) %*% a$X[[ k ]] + a$gTildes$muTilde[ k, ])
			r_log_Z <- r_log_Z + 0.5 * sum(q$m_w[ k, ] * v_aux)
			r_log_Z
		}

		for (k in 1 : a$nTasks) 
			log_Z <- log_Z + result[[ k ]]

	} else {
		for (k in 1 : a$nTasks) {
	
			n <- nrow(a$X[[ k ]])
			d <- a$d
	
			tX <- t.default(a$X[[ k ]])
			dX <- matrix(a$gTildes$nuTilde[ k, ]^-1, n, d, byrow = TRUE) * a$X[[ k ]]
	
			sLikelihood <- sum(a$fTildes$cTilde[[ k ]])
	
			log_Z <- log_Z + sLikelihood + sum(a$gTildes$sTilde[ k , ])
	
			log_Z <- log_Z + d / 2 * log(2 * pi)
	
			log_Z <- log_Z - 0.5 * (determinant(diag(n) + diag(1 / q$v_targets[[ k ]]) %*% a$X[[ k ]] %*% t.default(dX))$modulus[[1]] + 
				sum(log(abs(a$gTildes$nuTilde[ k, ]))))
	
			v_aux <- c((q$m_targets[[ k ]] / q$v_targets[[ k ]]) %*% a$X[[ k ]] + a$gTildes$muTilde[ k, ])
			log_Z <- log_Z + 0.5 * sum(q$m_w[ k, ] * v_aux)
		}
	}

	# We compute the contributions of the binary latent variables

	if (class == TRUE)
		log_Z <- log_Z + sum(log(exp(colSums(a$gTildes$zTilde[, -1 ]) + a$hTildes_z$logit_zTilde[ - 1 ]) + 1))
	else
		log_Z <- log_Z + sum(log(exp(colSums(a$gTildes$zTilde) + a$hTildes_z$logit_zTilde) + 1))

	log_Z <- log_Z + sum(a$hTildes_z$s_zTilde)
	log_Z <- log_Z + sum(a$lTildes_z$s_Tilde)
	log_Z <- log_Z + lbeta(sum(a$hTildes_z$a_zTilde) + sum(a$lTildes_z$a_Tilde) + 1, sum(a$hTildes_z$b_zTilde) + sum(a$lTildes_z$b_Tilde) + 1)

	if (class == TRUE)
		log_Z <- log_Z + sum(log(exp(rowSums(a$gTildes$omegaTilde[, -1 ]) + a$hTildes_omega$logit_omegaTilde) + 1))
	else
		log_Z <- log_Z + sum(log(exp(rowSums(a$gTildes$omegaTilde) + a$hTildes_omega$logit_omegaTilde) + 1))

	log_Z <- log_Z + sum(a$hTildes_omega$s_omegaTilde)
	log_Z <- log_Z + sum(a$lTildes_omega$s_Tilde)
	log_Z <- log_Z + lbeta(sum(a$hTildes_omega$a_omegaTilde) + sum(a$lTildes_omega$a_Tilde) + 1, 
		sum(a$hTildes_omega$b_omegaTilde) + sum(a$lTildes_omega$b_Tilde) + 1)

	if (class == TRUE)
		log_Z <- log_Z + sum(log(exp(colSums(a$gTildes$gammaTilde[, -1 ]) + a$hTildes_gamma$logit_gammaTilde[ -1 ]) + 1)) 
	else
		log_Z <- log_Z + sum(log(exp(colSums(a$gTildes$gammaTilde) + a$hTildes_gamma$logit_gammaTilde) + 1)) 

	log_Z <- log_Z + sum(a$hTildes_gamma$s_gammaTilde)
	log_Z <- log_Z + sum(a$lTildes_gamma$s_Tilde)
	log_Z <- log_Z + lbeta(sum(a$hTildes_gamma$a_gammaTilde) + sum(a$lTildes_gamma$a_Tilde) + 1, 
		sum(a$hTildes_gamma$b_gammaTilde) + sum(a$lTildes_gamma$b_Tilde) + 1)

	if (class == TRUE)
		log_Z <- log_Z + sum(log(exp(a$gTildes$tauTilde[, -1 ] + a$hTildes_tau$logit_tauTilde[ ,-1 ]) + 1))
	else
		log_Z <- log_Z + sum(log(exp(a$gTildes$tauTilde + a$hTildes_tau$logit_tauTilde) + 1))

	log_Z <- log_Z + sum(a$hTildes_tau$s_tauTilde)
	log_Z <- log_Z + sum(a$lTildes_tau$s_Tilde)
	log_Z <- log_Z + lbeta(sum(a$hTildes_tau$a_tauTilde) + sum(a$lTildes_tau$a_Tilde) + 1, 
		sum(a$hTildes_tau$b_tauTilde) + sum(a$lTildes_tau$b_Tilde) + 1)

	if (class == TRUE)
		log_Z <- log_Z + sum(log(exp(a$gTildes$etaTilde[ , -1 ]  + a$hTildes_eta$logit_etaTilde[, -1 ]) + 1))
	else
		log_Z <- log_Z + sum(log(exp(a$gTildes$etaTilde + a$hTildes_eta$logit_etaTilde) + 1))

	log_Z <- log_Z + sum(a$hTildes_eta$s_etaTilde)
	log_Z <- log_Z + sum(a$lTildes_eta$s_Tilde)
	log_Z <- log_Z + lbeta(sum(a$hTildes_eta$a_etaTilde) + sum(a$lTildes_eta$a_Tilde) + 1, 
		sum(a$hTildes_eta$b_etaTilde) + sum(a$lTildes_eta$b_Tilde) + 1)

	# The contribution of the gamma distribution for the noise

	if (class == FALSE) {

		log_Z <- log_Z + sum(a$kTildes$sTilde)

		if (a$shared_noise == TRUE) {
			alpha <- sum(sapply(a$fTildes$aTilde, function(x) sum(x))) + a$kTildes$aTilde
			beta <- sum(sapply(a$fTildes$bTilde, function(x) sum(x))) + a$kTildes$bTilde
		} else {
			alpha <- sapply(a$fTildes$aTilde, function(x) sum(x)) + a$kTildes$aTilde
			beta <- sapply(a$fTildes$bTilde, function(x) sum(x)) + a$kTildes$bTilde
		}

		log_Z <- log_Z + sum(lgamma(alpha - 1) - (alpha - 1) * log(beta))
	} 

	log_Z
}



