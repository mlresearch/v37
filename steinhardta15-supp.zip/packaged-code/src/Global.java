import java.util.*;
import fig.basic.LogInfo;
public class Global {
  static Map<Integer, Integer> key = new HashMap<Integer, Integer>();
  static int numWords;
  static Params pT, pTinit; // transition probabilities
  static double[][] pE; // emission probabilities
  static void trainBigram(List train){
    numWords = 0;
    for(Object o : train){
      int[] words = (int[])o;
      for(int word : words){
        numWords = Math.max(numWords, word + 1);
      }
    }
    if(Main.kn){
      pT = new KNTrie(0, Main.ngramLength, Main.KN_EPS, Main.KN_DISCOUNT, null);
    } else {
      pT = new Laplace(0.01);
    }
    pTinit = pT;
    for(Object o : train){
      int[] words = (int[])o;
      int[] prefix = new int[Main.ngramLength-1];
      for(int word : words){
        pT.add(new Prefix(prefix), word, 1.0);
        for(int i=0;i<Main.ngramLength-2;i++){
          prefix[i]=prefix[i+1];
        }
        prefix[Main.ngramLength-2] = word;
      }
    }
    pE = new double[numWords][numWords];
    double eps = 0.01;
    for(int i = 0; i < numWords; i++){
      for(int j = 0; j < numWords; j++){
        if(i!=0){
          if(j != 0){
            pE[i][j] = 1.0 / numWords;
          }
        } else { // '0' is a special word, denoting start of utterance
          if(j == 0){
            pE[i][j] = 1.0;
          }
        }
      }
    }
  }


  // keep track of n-gram counts
  final static int NGRAM_SIZE = 9999;
  static double[] lens =      new double[NGRAM_SIZE];
  static double[] ngrams =    new double[NGRAM_SIZE];
  static double[] lensCur =   new double[NGRAM_SIZE];
  static double[] ngramsCur = new double[NGRAM_SIZE];
  static long maxLen = 0, maxLenCur = 0;
  static long maxNGram = 0, maxNGramCur = 0;
  static void registerLen(int len, double wt){
    //lens[len]++;
    //lensCur[len]++;
    lens[len]+=wt;
    lensCur[len]+=wt;
    maxLen = Math.max(maxLen, len);
    maxLenCur = Math.max(maxLenCur, len);
    len = Math.min(len, Main.ngramLength); //Main.trigram ? 3 : 2);
    //ngrams[len]++;
    //ngramsCur[len]++;
    ngrams[len]+=wt;
    ngramsCur[len]+=wt;
    maxNGram = Math.max(maxNGram, 3);
    maxNGramCur = Math.max(maxNGramCur, 3);
  }
  static void clearLens(){
    lensCur =   new double[NGRAM_SIZE];
    ngramsCur = new double[NGRAM_SIZE];
    maxLenCur = 0;
    maxNGramCur = 0;
  }
  static void printLens(){
    LogInfo.begin_track("ngram statistics");
    double sum = 0, sum2 = 0;
    for(int i=0;i<NGRAM_SIZE;i++){ sum += lensCur[i]; sum2 += i * lensCur[i]; }
    LogInfo.begin_track("lens cur (avg = %.2f)", sum2 / (double) sum);
    for(int i=0;i<NGRAM_SIZE;i++){
      if(lensCur[i] != 0) LogInfo.logs("%d: %.2f %.2f", i, lensCur[i], lensCur[i] / (double) sum);
    }
    LogInfo.end_track();
    sum = 0; sum2 = 0;
    for(int i=0;i<=maxNGramCur;i++){ sum += ngramsCur[i]; sum2 += i * ngramsCur[i]; }
    LogInfo.begin_track("ngrams cur (avg = %.2f)", sum2 / (double) sum);
    for(int i=0;i<=maxNGramCur;i++){
      LogInfo.logs("%d: %.2f %.2f", i, ngramsCur[i], ngramsCur[i] / (double) sum);
    }
    LogInfo.end_track();
    sum = 0; sum2 = 0;
    for(int i=0;i<NGRAM_SIZE;i++){ sum += lens[i]; sum2 += i * lens[i]; }
    LogInfo.begin_track("lens total (avg = %.2f)", sum2 / (double) sum);
    for(int i=0;i<NGRAM_SIZE;i++){
      if(lens[i] != 0) LogInfo.logs("%d: %.2f %.2f", i, lens[i], lens[i] / (double) sum);
    }
    LogInfo.end_track();
    sum = 0; sum2 = 0;
    for(int i=0;i<=maxNGram; i++){ sum += ngrams[i]; sum2 += i * ngrams[i]; }
    LogInfo.begin_track("ngrams total (avg = %.2f)", sum2 / (double) sum);
    for(int i=0;i<=maxNGram;i++){
      LogInfo.logs("%d: %.2f %.2f", i, ngrams[i], ngrams[i] / (double) sum);
    }
    LogInfo.end_track();
    LogInfo.end_track();
  }
}
