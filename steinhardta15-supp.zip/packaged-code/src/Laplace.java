import java.util.*;
public class Laplace implements Params {
  HashMap<Prefix, Double> count1;
  HashMap<Prefix, HashMap<Integer, Double>> count2;
  double eps;
  Laplace init;
  public Laplace(double eps){
    this.eps = eps;
    this.init = null;
    count1 = new HashMap<Prefix, Double>();
    count2 = new HashMap<Prefix, HashMap<Integer, Double>>();
  }
  public Laplace(Params _init){
    init = (Laplace)_init;
    this.eps = init.eps;
    count1 = new HashMap<Prefix, Double>();
    count2 = new HashMap<Prefix, HashMap<Integer, Double>>();
  }
  @Override
  public void add(Prefix p, int i, double wt){
    Double x = count1.get(p);
    if(x == null) count1.put(p, wt);
    else count1.put(p, wt + x);
    HashMap<Integer, Double> m = count2.get(p);
    if(m == null){
      m = new HashMap<Integer, Double>();
      count2.put(p, m);
    }
    Double y = m.get(i);
    if(y == null) m.put(i, wt);
    else m.put(i, wt + y);
  }
  private double getNumCount(Prefix p, int i){
    HashMap<Integer, Double> m = count2.get(p);
    if(m == null) return 0.0;
    Double x = m.get(i);
    if(x == null) return 0.0;
    return x;
  }
  private double getDenomCount(Prefix p){
    Double x = count1.get(p);
    if(x == null) return 0.0;
    return x;
  }
  @Override
  public double get(Prefix p, int i){
    double num = getNumCount(p, i),
           denom = getDenomCount(p);
    if(init != null){
      num += init.getNumCount(p, i);
      denom += init.getDenomCount(p);
    }
    return (num + eps) / (denom + eps * Global.numWords);
  }
}
