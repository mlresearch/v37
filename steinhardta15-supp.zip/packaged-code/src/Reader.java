import java.util.*;
import java.io.*;
public class Reader {
  public static Data read(String source) throws Exception {
    Scanner plain = new Scanner(new File(source+"/plain.dat"));
    Scanner cipher = new Scanner(new File(source+"/cipher.dat"));
    Data ret = new Data();
    while(plain.hasNextLine()){
      ret.addPlain(Util.toInts(plain.nextLine()));
    }
    while(cipher.hasNextLine()){
      ret.addCipher(Util.toInts(cipher.nextLine()));
    }
    Scanner key = new Scanner(new File(source+"/key.dat"));
    Global.key.put(0, 0);
    while(key.hasNextLine()){
      String[] toks = key.nextLine().split("\\s");
      Global.key.put(Integer.parseInt(toks[0]), Integer.parseInt(toks[1]));
    }
    return ret;
  }
}
