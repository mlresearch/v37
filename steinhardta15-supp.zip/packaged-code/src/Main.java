import java.util.*;
import fig.basic.LogInfo;
import fig.basic.Option;
import fig.basic.OptionsParser;
import fig.basic.StatFig;
import fig.exec.Execution;

public class Main implements Runnable {
  @Option(gloss="experiment name (for easier tracking)")
  public static String experimentName = "UNKNOWN";
  @Option(required=true)
  public static String dataSource;
  @Option(required=true)
  public static int numIters;
  @Option(required=true)
  public static int beamSize;
  @Option(required=true)
  public static int inferType;
  final public static int EXACT = 0, BEAM = 1, ABSTRACT = 2;
  @Option(required=true)
  public static int ngramLength;
  @Option(required=true, gloss="whether to use decoded cipher text to update the language model")
  public static boolean updateLM = false;
  @Option
  public static double KN_DISCOUNT = 0.25;
  @Option
  public static double KN_EPS = 0.01;
  @Option(gloss="whether to use absolute discounting")
  public static boolean kn = true;
  
  public void run() {
    try {
      runWithException();
    } catch(Exception e) {
			e.printStackTrace();
      throw new RuntimeException();
    }
  }


  void runWithException() throws Exception {
    if(inferType == EXACT && ngramLength != 2){
      throw new RuntimeException("cannot run exact inference except for bigrams");
    }

    Data data = Reader.read(dataSource);
    Global.trainBigram(data.plain);
    for(int iter = 0; iter < numIters; iter++){
      Global.clearLens();
      Infer.update(data.cipher);
      Global.printLens();
      LogInfo.begin_track("Printing pE");
      int numCorrect = 0;
      for(int i = 0; i < Global.numWords; i++){
        String str = "";
        int best = 0;
        for(int j = 0; j < Global.numWords; j++){
          if(Global.pE[i][j] > Global.pE[i][best]) best = j;
          str += String.format("%.3f ", Global.pE[i][j]);
        }
        boolean ok = (best == Global.key.get(i));
        LogInfo.logs("%2d%s\t| %s", best, ok ? " " : "*", str);
        if(ok) numCorrect++;
      }
      LogInfo.logs("numCorrect: %d/%d", numCorrect, Global.numWords);
      LogInfo.end_track();
    }
  }

  public static void main(String[] args){
    OptionsParser parser = new OptionsParser();                 
    parser.registerAll(
      new Object[]{
        });               

    Execution.run(args, "Main", new Main(), parser);
  }
}
