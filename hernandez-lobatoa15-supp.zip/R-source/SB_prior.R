##
# This file contains the required information for carrying out approximate inference in a linear regression model
# based on the Strawderman-Bergen Prior and a spike centered at the origin
#

# This library is used to evaluate the error function

library(NORMT3)

# This is the Strawderman Bergen Prior

prior <- function(x) 1 / sqrt(2 * pi) * (1 - abs(x) * exp(pnorm(abs(x), lower.tail = FALSE, log.p = TRUE) - dnorm(x, log = TRUE)))

##
# This function evaluates the log of the erf when evaluated in complex numbers
#

log_erfi <- function(x) {

	result <- rep(0i, length(x))

	too_large <- abs(Im(x)) > 25

	if (any(too_large)) {
		w <- abs(Im(x[ too_large ])); 
		w <- w^2 -0.5 * log(pi) + log(w^-1 + 0.5 * w^-3 + 3 / 4 * w^-5 + 15 / 8 * w^-7 + 105 / 16 * w^-9) + sign(Im(x[ too_large ])) * log(1i) 
		result[ too_large ] <- w
	} 

	if (any(! too_large)) {
		result[ ! too_large ] <- log(erf(x[ ! too_large ]))
	}

	result
}

##
# This function evaluates the key function that is needed for the evaluation of the
# convolution of the Strawderman-Bergen prior with a gaussian with mean m and variance s
#
# The prior is defined as  1 / sqrt(2 * pi) * (1 - abs(x) * pnorm(-abs(x)) / dnorm(x))
#
# The difference is
#
# (exp(0.5 * m^2 / (1 - s)) * erf(- m / sqrt(2) * 1 / sqrt(1 - s)) - 
# exp(0.5 * m^2 / (1 - s)) * erf(- m / sqrt(2) * 1 / sqrt(1 - s) * 1 / sqrt(s))) / sqrt(1 - s)
#
# Define v = m / sqrt(1 - s)
#
# (exp(0.5 * v^2) * erf(- v / sqrt(2)) - 
#  exp(0.5 * v^2) * erf(- v / sqrt(2) * 1 / sqrt(s))) / sqrt(1 - s)
#
# (exp(v^2 / 2) * erf(- v / sqrt(2)) - 
#  exp(v^2 / 2) * erf(- v / sqrt(2) * 1 / sqrt(s))) / sqrt(1 - s)
#
# exp(0.5 * v^2) * (erf(- v / sqrt(2)) - erf(- v / sqrt(2) * 1 / sqrt(s))) / sqrt(1 - s)

# Arguments:
#
# m -> Mean of the Gaussian to convolve with
# s -> Variance of the Gaussian to convolve with
#

evaluate_diff <- function(m, s) {

	result <- rep(0, max(length(m), length(s)))

	is_complex <- 1 - s < 0
	mean_equal_zero <- m == 0

	if (any((! is_complex) & (! mean_equal_zero))) {

		to_sel <- (! is_complex) & (! mean_equal_zero)

		v <- m[ to_sel ] / sqrt(1 - s[ to_sel ]) / sqrt(2)

		log_a <- pnorm(sqrt(2) * - abs(v), 0, 1, log.p = TRUE) + log(2)
		log_b <- pnorm(sqrt(2) * - abs(v) * 1 / sqrt(s[ to_sel ]), 0, 1, log.p = TRUE) + log(2) 

		max_log_value <- pmax(log_a, log_b)

		log_diff <- log(abs(exp(log_a - max_log_value) - exp(log_b - max_log_value))) + max_log_value

		result[ to_sel ] <- sign(m[ to_sel ]) * exp(log_diff - 0.5 * log(1 - s[ to_sel ]) + v^2)
	}

	if (any(is_complex & (! mean_equal_zero))) {

		to_sel <- is_complex & (! mean_equal_zero)

		v <- m[ to_sel ] / sqrt(1 - s[ to_sel ] + 0i) / sqrt(2)

		log_a <- log_erfi(-v)
		log_b <- log_erfi(-v / sqrt(s[ to_sel ]))

		max_log_value <- log_a
		is_max_log_value <- pmax(Mod(log_a), Mod(log_b))
		max_log_value[ is_max_log_value == Mod(log_b) ] <- log_b[ is_max_log_value == Mod(log_b) ]

		log_diff <- log(exp(log_a - max_log_value) - exp(log_b - max_log_value)) + max_log_value

		result[ to_sel ] <- Re(exp(log_diff - 0.5 * log(1 - s[ to_sel ] + 0i) + v^2))
	}

	if (any(mean_equal_zero)) 
		result[ mean_equal_zero ] <- 0

	result
}

##
# This function evaluates the convolution of a Gaussian distribution with the Strawderman-Bergen prior
#
# The prior is defined as  1 / sqrt(2 * pi) * (1 - abs(x) * pnorm(-abs(x)) / dnorm(x))
#
# m -> Mean of the Gaussian to convolve with
# s -> Variance of the Gaussian to convolve with
#

log_conv_SB <- function(m, s) {

	result <- rep(0, max(length(m), length(s)))

	equal_to_one <- abs(1 - s) < 1e-4
	mean_equal_to_zero <- m == 0

	if (any(! equal_to_one)) {

		s_no_equal_to_one <- s[ ! equal_to_one ]
		m_no_equal_to_one <- m[ ! equal_to_one ]

 		result[ ! equal_to_one ] <- log(abs(1 / sqrt(2 * pi) - 
			1 / sqrt(2 * pi) * exp(-0.5 * m_no_equal_to_one^2 / s_no_equal_to_one) * 
			sqrt(s_no_equal_to_one) - m_no_equal_to_one / 2 * evaluate_diff(m_no_equal_to_one, s_no_equal_to_one))) - 
			log(abs(1 - s_no_equal_to_one))
	}
	
	if (any(equal_to_one & (! mean_equal_to_zero))) {

		to_sel <- equal_to_one & (! mean_equal_to_zero)

		s_equal_to_one <- s[ to_sel ]
		m_equal_to_one <- m[ to_sel ]
		
		result[ to_sel ] <- -0.5 * log(2 * pi) + -2 * log(abs(m_equal_to_one)) + pexp(m_equal_to_one^2, 0.5, log.p = TRUE)
	}
	
	if (any(equal_to_one & mean_equal_to_zero)) {

		to_sel <- equal_to_one & mean_equal_to_zero

		result[ to_sel ] <- -0.5 * log(2 * pi) - log(2)
	}

	result
}

##
# This function evaluates the derivative of the log of the convolution of a Gaussian distribution with the Strawderman-Bergen prior
# with respect to the mean of the gaussian
#
# m -> Mean of the Gaussian to convolve with
# s -> Variance of the Gaussian to convolve with
#

dlog_conv_SB_dm <- function(m, s) {

	result <- rep(0, max(length(m), length(s)))
	equal_to_one <- abs(1 - s) < 1e-4
	zero_mean <- m == 0

	if (any(! equal_to_one & ! zero_mean)) {

		to_sel <- ! equal_to_one & ! zero_mean
	
		m_not_equal_to_one <- m[ to_sel ]
		s_not_equal_to_one <- s[ to_sel ]

		result[ to_sel ] <- (m_not_equal_to_one * 1 / sqrt(2 * pi) - 1 / sqrt(2 * pi * s_not_equal_to_one) * 
			s_not_equal_to_one * exp(-0.5 * m_not_equal_to_one^2 / s_not_equal_to_one) * m_not_equal_to_one -
			(m_not_equal_to_one^2 + 1 - s_not_equal_to_one) / 2 * evaluate_diff(m_not_equal_to_one, s_not_equal_to_one)) / 
			(exp(log_conv_SB(m_not_equal_to_one, s_not_equal_to_one)) * (1 - s_not_equal_to_one)^2)
	}

	if (any(equal_to_one & ! zero_mean)) {

		to_sel <- equal_to_one & abs(m) > 1e-5 & ! zero_mean
		m_equal_to_one <- m[ to_sel ]

		# We use the formula  m * (1 / sqrt(2 * pi) / m^2 * exp(-m^2 / 2) - 1 / sqrt(2 * pi) / m^4 * 2 * (1 - exp(-m^2/2))) /
		#       exp(log_conv(m, 1))

		log_a <- -0.5 * log(2 * pi) - 2 * log(abs(m_equal_to_one)) - m_equal_to_one^2 / 2
		log_b <- -0.5 * log(2 * pi) - 4 * log(abs(m_equal_to_one)) + log(2) + pexp(m_equal_to_one^2, 0.5, log.p = TRUE)

		max_log_value <- pmax(log_a, log_b)
		log_diff <- log(abs(exp(log_a - max_log_value) - exp(log_b - max_log_value))) + max_log_value

		result[ to_sel ] <- -m_equal_to_one * exp(log_diff) / exp(log_conv_SB(m_equal_to_one, rep(1, length(m_equal_to_one))))

		# We use the fact that in the viciinty of 0 exp(x) is equal to 1 + x + x^2 / 2 + x^3 / 6. In this case the above is equal to
	
		# m * (1/sqrt(2*pi) * 1 / m^2 * (1 + -m^2 / 2 + m^4/8) - 1/sqrt(2*pi) * 1 / m^4 * 2 * (m^2/2 - m^4/8)) / exp(log_conv(m, 1))

		# m * (1 / sqrt(2 * pi) * (1 / m^2 * (1 + -m^2 / 2 + m^4 / 8) - 1 / m^4 * 2 * (m^2/2 - m^4 / 8))) / exp(log_conv(m, 1))
		# m * (1 / sqrt(2 * pi) * (1 / m^2 - 1 / 2 + m^2 / 8 - 1 / m^2 + 1 / 4)) / exp(log_conv(m, 1))
		# m * (1 / sqrt(2 * pi) * (- 1 / 4 + m^2 / 8)) / exp(log_conv(m, 1))
		# m * (1 / sqrt(2 * pi) * (m^2 / 8 - 1 / 4)) / exp(log_conv(m, 1))
		# - m / 4  * 1 / sqrt(2 * pi) / exp(log_conv(m, 1)) + m^3 / 8 * 1 / sqrt(2 * pi) / exp(log_conv(m, 1))
		# - m / 4  * 1 / sqrt(2 * pi) / exp(log_conv(m, 1)) 

		to_sel <- equal_to_one & abs(m) < 1e-5 & ! zero_mean
		m_equal_to_one <- m[ to_sel ]

		result[ to_sel ] <- - m_equal_to_one / 4  * 1 / sqrt(2 * pi) / exp(log_conv_SB(m_equal_to_one, rep(1, length(m_equal_to_one)))) 
	}

	if (any(zero_mean)) 
		result[ zero_mean ] <- 0
	
	result
}

##
# This function evaluates the second derivative of the log of the convolution of a Gaussian distribution with the Strawderman-Bergen prior
# with respect to the mean of the gaussian
#
# m -> Mean of the Gaussian to convolve with
# s -> Variance of the Gaussian to convolve with
#

d2log_conv_SB_dm2 <- function(m, s) {

	result <- rep(0, max(length(m), length(s)))
	equal_to_one <- abs(1 - s) < 1e-4
	zero_mean <- m == 0

	if (any(! equal_to_one & ! zero_mean)) {

		to_sel <- ! equal_to_one & ! zero_mean
	
		m_not_equal_to_one <- m[ to_sel ]
		s_not_equal_to_one <- s[ to_sel ]

		result[ to_sel ] <- (1 / sqrt(2 * pi) * (2 + m_not_equal_to_one^2 / (1 - s_not_equal_to_one)) - 
			1 / sqrt(2 * pi * s_not_equal_to_one) * exp(-0.5 * m_not_equal_to_one^2 / s_not_equal_to_one) * 
			(m_not_equal_to_one^2 / (1 - s_not_equal_to_one) + 1 + s_not_equal_to_one - m_not_equal_to_one^2) -
			(m_not_equal_to_one + (m_not_equal_to_one^2 + 1 - s_not_equal_to_one) / 2 * m_not_equal_to_one / (1 - s_not_equal_to_one)) * 
			evaluate_diff(m_not_equal_to_one, s_not_equal_to_one)) / 
			(exp(log_conv_SB(m_not_equal_to_one, s_not_equal_to_one)) * (1 - s_not_equal_to_one)^2) - 
			dlog_conv_SB_dm(m_not_equal_to_one, s_not_equal_to_one)^2
	}

	if (any(equal_to_one & ! zero_mean)) {

		to_sel <- equal_to_one & abs(m) > 1e-5 & ! zero_mean
		m_equal_to_one <- m[ to_sel ]

		result[ to_sel ] <- - 1 / sqrt(2 * pi) * exp(-m_equal_to_one^2/ 2) / exp(log_conv_SB(m_equal_to_one, 1)) - 
			3 / z * dlog_conv_SB_dm(m_equal_to_one, 1) - dlog_conv_SB_dm(m_equal_to_one, 1)^2

		to_sel <- equal_to_one & abs(m) < 1e-5 & ! zero_mean
		m_equal_to_one <- m[ to_sel ]

		result[ to_sel ] <- - 1 / 4  * 1 / sqrt(2 * pi) / exp(log_conv_SB(m_equal_to_one, 1)) + dlog_conv_SB_dm(m_equal_to_one, 1)^2
	}

	if (any(zero_mean)) 
		result[ zero_mean ] <- - 1 / 4  * 1 / sqrt(2 * pi) / exp(log_conv_SB(m_equal_to_one, 1)) + dlog_conv_SB_dm(m_equal_to_one, 1)^2
	
	result
}


##
# This function evaluates the derivative of the log of the convolution of a Gaussian distribution with the Strawderman-Bergen prior
# with respect to the variance of the gaussian
#
# m -> Mean of the Gaussian to convolve with
# s -> Variance of the Gaussian to convolve with
#

dlog_conv_SB_ds <- function(m, s) {

	result <- rep(0, max(length(m), length(s)))
	equal_to_one <- abs(1 - s) < 1e-2
	is_zero_mean <- m == 0

	if (any(! equal_to_one)) {

		to_sel <- ! equal_to_one
		m_not_equal_to_one <- m[ to_sel ]
		s_not_equal_to_one <- s[ to_sel ]
	
		result[ to_sel ] <- (2 / sqrt(2 * pi) * (1 - s_not_equal_to_one + m_not_equal_to_one^2 / 2) -
			1 / sqrt(2 * pi) * exp(-0.5 * m_not_equal_to_one^2 / s_not_equal_to_one) * 
			(1 / s_not_equal_to_one - s_not_equal_to_one + m_not_equal_to_one^2) * sqrt(s_not_equal_to_one) -
			(3 * (1 - s_not_equal_to_one) + m_not_equal_to_one^2) * m_not_equal_to_one / 2 *
			evaluate_diff(m_not_equal_to_one, s_not_equal_to_one)) / 
			(2 * exp(log_conv_SB(m_not_equal_to_one, s_not_equal_to_one)) * (1 - s_not_equal_to_one)^3)
	}

	if (any(equal_to_one & ! is_zero_mean)) {

		to_sel <- equal_to_one & ! is_zero_mean
		m_equal_to_one <- m[ to_sel ]
		s_equal_to_one <- s[ to_sel ]
	
		result[ to_sel ] <- (4 / m_equal_to_one^4 * 1 / sqrt(2 * pi) * pgamma(0.5 * m_equal_to_one^2, 3) - 
			1 / m_equal_to_one^4 * 1 / sqrt(2 * pi) * pgamma(0.5 * m_equal_to_one^2, 2)) / 
			exp(log_conv_SB(m_equal_to_one, rep(1, length(m_equal_to_one))))
	}

	if (any(equal_to_one & is_zero_mean)) {

		to_sel <- equal_to_one & is_zero_mean
	
		result[ to_sel ] <- - 1 / 4
	}

	result
}

##
# This function evaluates the second derivative of the log of the convolution of a Gaussian distribution with the Strawderman-Bergen prior
# with respect to the variance of the gaussian
#
# m -> Mean of the Gaussian to convolve with
# s -> Variance of the Gaussian to convolve with
#

d2log_conv_SB_ds2 <- function(m, s) {

	result <- rep(0, max(length(m), length(s)))
	equal_to_one <- abs(1 - s) < 1e-1
	is_zero_mean <- m == 0

	if (any(! equal_to_one)) {

		to_sel <- ! equal_to_one
		m_not_equal_to_one <- m[ to_sel ]
		s_not_equal_to_one <- s[ to_sel ]
	
		result[ to_sel ] <- (- 2 / sqrt(2 * pi) + 3 / sqrt(2 * pi) * m_not_equal_to_one^2 / 2 * 1 / (1 - s_not_equal_to_one) + 
			m_not_equal_to_one^4 * 1 / sqrt(2 * pi) * 1 / 2 * 1 / (1 - s_not_equal_to_one)^2 + 
			1 / sqrt(2 * pi * s_not_equal_to_one) * exp(-0.5 * m_not_equal_to_one^2 / s_not_equal_to_one) * 1 / 2 * 
			(3 * s_not_equal_to_one - m_not_equal_to_one^2 / s_not_equal_to_one^2 - 3 * m_not_equal_to_one^2 / (1 - s_not_equal_to_one) +
			3 * m_not_equal_to_one^2 / s_not_equal_to_one + 1 / s_not_equal_to_one - m_not_equal_to_one^4 * s_not_equal_to_one /
			(1 - s_not_equal_to_one)^2) -
			1 / 2 * (4 * m_not_equal_to_one^3 / 2 * 1 / (1 - s_not_equal_to_one) - 3 * m_not_equal_to_one / 2 + 
			m_not_equal_to_one^5 / 2 * 1 / (1 - s_not_equal_to_one)^2)  * evaluate_diff(m_not_equal_to_one, s_not_equal_to_one)) / 
			(2 * exp(log_conv_SB(m_not_equal_to_one, s_not_equal_to_one)) * (1 - s_not_equal_to_one)^3) - 
			(dlog_conv_SB_ds(m_not_equal_to_one, s_not_equal_to_one) - 3 / (1 - s_not_equal_to_one)) * 
			dlog_conv_SB_ds(m_not_equal_to_one, s_not_equal_to_one)
	}

	if (any(equal_to_one & ! is_zero_mean)) {

		to_sel <- equal_to_one & ! is_zero_mean
		m_equal_to_one <- m[ to_sel ]
		s_equal_to_one <- s[ to_sel ]
	
		result[ to_sel ] <- (gamma(3) * 1 / (0.5 * m_equal_to_one^2)^3 * 0.5 * 0.5 * 3 / 2 * 1 / sqrt(2 * pi) * 
			pgamma(0.5 * m_equal_to_one^2, 3) + gamma(4) * 1 / (0.5 * m_equal_to_one^2)^4 * -
			0.5 * m_equal_to_one^2 * 0.5 * 0.5 * 1 / sqrt(2 * pi) * pgamma(0.5 * m_equal_to_one^2, 4) +
			gamma(5) * 1 / (0.5 * m_equal_to_one^2)^5 * 0.5 * m_equal_to_one^4 * 0.5  * 0.5 * 1 / sqrt(2 * pi) * 
			pgamma(0.5 * m_equal_to_one^2, 5) + gamma(4) * 1 / (0.5 * m_equal_to_one^2)^4 * 0.5 * -5 / 2 * m_equal_to_one^2 * 
			0.5 * 1 / sqrt(2 * pi) * pgamma(0.5 * m_equal_to_one^2, 4)) / exp(log_conv_SB(m_equal_to_one, 1)) -
			dlog_conv_SB_ds(m_equal_to_one, 1)^2
	}

	if (any(equal_to_one & is_zero_mean)) {

		to_sel <- equal_to_one & is_zero_mean
	
		result[ to_sel ] <- 3 / 16
	}

	result
}



##
# This function evaluates the convolution of a Gaussian distribution with the spike
#
# m -> Mean of the Gaussian to convolve with
# s -> Variance of the Gaussian to convolve with
# v0 <- variance of the spike
#

log_conv_spike <- function(m, s, v0) {
	dnorm(0, m, sqrt(s + v0), log = TRUE)
}

##
# This function evaluates the derivative with respect to the mean of the convolution of a Gaussian distribution with the spike
#
# m -> Mean of the Gaussian to convolve with
# s -> Variance of the Gaussian to convolve with
# v0 <- variance of the spike
#

dlog_conv_spike_dm <- function(m, s, v0) {
	- m / (s + v0)
}

##
# This function evaluates the derivative with respect to the variance of the convolution of a Gaussian distribution with the spike
#
# m -> Mean of the Gaussian to convolve with
# s -> Variance of the Gaussian to convolve with
# v0 <- variance of the spike
#

dlog_conv_spike_ds <- function(m, s, v0) {
	0.5 * (m^2 - s - v0) / (s + v0)^2
}

##
# This function evaluates the convolution of an unormalized Gaussian distribution with the spike
#
# m -> Mean divided by variance 
# s -> Precision of the Gaussian to convolve with
# v0 <- variance of the spike
#

log_conv_Gauss_natural_paramters <- function(m, s, v0) {
	v_new <- s + v0^-1
	m_new <- m
	-0.5 * log(v_new) - 0.5 * log(v0) + 0.5 * m_new^2 / v_new
}

dlog_conv_Gauss_natural_paramters_dm <- function(m, s, v0) {
	v_new <- s + v0^-1
	m_new <- m
	m_new / v_new
}

d2log_conv_Gauss_natural_paramters_dm2 <- function(m, s, v0) {
	v_new <- s + v0^-1
	m_new <- m
	1 / v_new
}

dlog_conv_Gauss_natural_paramters_ds <- function(m, s, v0) {
	v_new <- s + v0^-1
	m_new <- m
	-0.5 * 1 / (v_new) - 0.5 * m_new^2 / v_new^2 
}

d2log_conv_Gauss_natural_paramters_ds2 <- function(m, s, v0) {
	v_new <- s + v0^-1
	m_new <- m
	0.5 * 1 / (v_new)^2 + m_new^2 / v_new^3 
}

d2log_conv_Gauss_natural_paramters_dmds <- function(m, s, v0) {
	v_new <- s + v0^-1
	m_new <- m
	- m_new / v_new^2
}

d2log_conv_Gauss_natural_paramters_dsdm <- function(m, s, v0) {
	v_new <- s + v0^-1
	m_new <- m
	- m_new / v_new^2 
}

#log_conv_SB <- function(m, s) log_conv_spike(m, s, 3)
#dlog_conv_SB_dm <- function(m, s) dlog_conv_spike_dm(m, s, 3)
#dlog_conv_SB_ds <- function(m, s) dlog_conv_spike_ds(m, s, 3)
