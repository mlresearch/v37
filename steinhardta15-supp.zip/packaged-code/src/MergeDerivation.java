import java.util.*;
public class MergeDerivation {
  List<ExpandDerivation> backpointers;
  MergeDerivation prev;
  int x;
  int len;
  double score, back;
  public MergeDerivation(){
    prev = this;
    backpointers = new ArrayList<ExpandDerivation>();
    x = Global.numWords;
    score = Double.NEGATIVE_INFINITY;
    back = Double.NEGATIVE_INFINITY;
    len = 0;
  }
  public MergeDerivation(ExpandDerivation template){
    prev = template.prev;
    backpointers = new ArrayList<ExpandDerivation>();
    backpointers.add(template);
    x = template.x;
    score = template.score;
    back = Double.NEGATIVE_INFINITY;
    len = template.len;
  }
  void absorb(ExpandDerivation deriv){
    backpointers.add(deriv);
    score = Util.logsumexp(score, deriv.score);
  }
  void backprop(){
    for(ExpandDerivation deriv : backpointers){
      // note: this uses the fact that each Expand gets merged into only a single Merge
      deriv.back = back;
    }
  }
}
