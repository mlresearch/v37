##
# This file contains the required information for carrying out approximate inference in a linear regression model
# based on the Strawderman-Bergen Prior and a spike centered at the origin
#

# This library is used to evaluate the error function

library(NORMT3)

# This is the Strawderman Bergen Prior

prior <- function(x) 1 / sqrt(2 * pi) * (1 - abs(x) * exp(pnorm(abs(x), lower.tail = FALSE, log.p = TRUE) - dnorm(x, log = TRUE)))

##
# This function evaluates the log of the erf when evaluated in complex numbers
#

log_erfi <- function(x) {

	result <- rep(0i, length(x))

	too_large <- abs(Im(x)) > 25

	if (any(too_large)) {
		w <- abs(Im(x[ too_large ])); 
		w <- w^2 -0.5 * log(pi) + log(w^-1 + 0.5 * w^-3 + 3 / 4 * w^-5 + 15 / 8 * w^-7 + 105 / 16 * w^-9) + 
			sign(Im(x[ too_large ])) * log(1i) 
		result[ too_large ] <- w
	} 

	if (any(! too_large)) {
		result[ ! too_large ] <- log(erf(x[ ! too_large ]))
	}

	result
}

log_erf <- function(x) {
	
	is_complex <- Im(x) != 0

	result <- rep(0, length(x))

	# If it is a complex number we simply call the log_erfi function

	if (any(is_complex)) 
		result[ is_complex ] <- log_erfi(x[ is_complex ])

	# If it is not complex we distinguish between positive and negative cases 

	if (any(! is_complex)) {

		is_real_and_pos <- ! is_complex
		is_real_and_pos[ is_real_and_pos ] <- is_real_and_pos[ is_real_and_pos ]  & Re(x[ is_real_and_pos ]) >= 0

		if (any(is_real_and_pos))
			result[ is_real_and_pos ] <- log(2) + pnorm(sqrt(2) * Re(x[ is_real_and_pos ]), 
				log.p = TRUE, lower.tail = FALSE) + log(-1 + 0i)
	
		is_real_and_neg <- ! is_complex
		is_real_and_neg[ is_real_and_neg ] <- is_real_and_neg[ is_real_and_neg ]  & Re(x[ is_real_and_neg ]) < 0
	
		if (any(is_real_and_neg))
			result[ is_real_and_neg ] <- log(2) + pnorm(sqrt(2) * Re(x[ is_real_and_neg ]), log.p = TRUE, lower.tail = TRUE) 
	}
	
	result
}

log_dlog_erf_dx <- function(x) {

	is_complex <- Im(x) != 0

	result <- rep(0, length(x))

	if (any(is_complex)) 
		result[ is_complex ] <- log(2) - 0.5 * log(pi) - x[ is_complex ]^2 - log_erf(x[ is_complex ])

	if (any(! is_complex)) {

		is_real_and_pos <- ! is_complex
		is_real_and_pos[ is_real_and_pos ] <- is_real_and_pos[ is_real_and_pos ]  & Re(x[ is_real_and_pos ]) >= 0

		if (any(is_real_and_pos))
			result[ is_real_and_pos ] <- log(2) + dnorm(sqrt(2) * Re(x[ is_real_and_pos ]), log = TRUE) + 
				0.5 * log(2) - log_erf(x[ is_real_and_pos ]) 

		is_real_and_neg <- ! is_complex
		is_real_and_neg[ is_real_and_neg ] <- is_real_and_neg[ is_real_and_neg ]  & Re(x[ is_real_and_neg ]) < 0
	
		if (any(is_real_and_neg))
			result[ is_real_and_neg ] <- log(2) + dnorm(sqrt(2) * Re(x[ is_real_and_neg ]), log = TRUE) + 
				0.5 * log(2) - log_erf(x[ is_real_and_neg ])
	}

	result
}

log_d2log_erf_dx2 <- function(x) {

	is_complex <- Im(x) != 0

	result <- rep(0, length(x))

	if (any(is_complex)) {

		log_v1 <- 2 * log(2) - 0.5 * log(pi) - x[ is_complex ]^2 - log_erf(x[ is_complex ]) + log(-x[ is_complex ])
		log_v2 <- 2 * log_dlog_erf_dx(x[ is_complex ])

		max <- log_v1
		max[ Re(max) < Re(log_v2) ] <- log_v2[ Re(max) < Re(log_v2) ]

		result[ is_complex ]  <- log(exp(log_v1 - max) - exp(log_v2 - max)) + max
	}

	if (any(! is_complex)) {

		is_real_and_pos <- ! is_complex
		is_real_and_pos[ is_real_and_pos ] <- is_real_and_pos[ is_real_and_pos ]  & Re(x[ is_real_and_pos ]) >= 0

		if (any(is_real_and_pos)) {

			log_v1 <- 2 * log(2) + dnorm(sqrt(2) * Re(x[ is_real_and_pos ]), log = TRUE) + 
				+ log(-x[ is_real_and_pos ] + 0i) + 0.5 * log(2) - log_erf(x[ is_real_and_pos ])
			log_v2 <- 2 * log_dlog_erf_dx(x[ is_real_and_pos ])
 
			max <- log_v1
			max[ Re(max) < Re(log_v2) ] <- log_v2[ Re(max) < Re(log_v2) ]

			result[ is_real_and_pos ] <- log(exp(log_v1 - max) - exp(log_v2 - max)) + max
		}

		is_real_and_neg <- ! is_complex
		is_real_and_neg[ is_real_and_neg ] <- is_real_and_neg[ is_real_and_neg ]  & Re(x[ is_real_and_neg ]) < 0
	
		if (any(is_real_and_neg)) {

			log_v1 <- 2 * log(2) + dnorm(sqrt(2) * Re(x[ is_real_and_neg ]), log = TRUE) + 
				0.5 * log(2) - log_erf(x[ is_real_and_neg ]) + log(-x[ is_real_and_neg ] + 0i)
			log_v2 <- 2 * log_dlog_erf_dx(x[ is_real_and_neg ])

			max <- log_v1
			max[ Re(max) < Re(log_v2) ] <- log_v2[ Re(max) < Re(log_v2) ]

			result[ is_real_and_neg ] <- log(exp(log_v1 - max) - exp(log_v2 - max)) + max
		}
	}

	result
}

log_conv_SB <- function(m, s) {

	eq_one <- abs(s - 1) < 1e-3
	result <- rep(0, max(length(m), length(s)))

	if (any(! eq_one)) {

		m_neq_one <- m[ ! eq_one ]
		s_neq_one <- s[ ! eq_one ]

		x <- m_neq_one / sqrt(s_neq_one - 1 + 0i) / sqrt(2)

		log_a <- 0.5 * log(s_neq_one)  + 0.5 * m_neq_one^2 / s_neq_one - log(s_neq_one - 1 + 0i)
		log_b <- 0 + log(-1 + 0i) - log(s_neq_one - 1 + 0i)
		log_c <- 0.5 * log(2 * pi) + log(m_neq_one + 0i) - log(2) + x^2 + 
			log_erf(-x / sqrt(s_neq_one)) - 3 / 2 * log(s_neq_one - 1 + 0i) + log(-1 + 0i)
		log_d <- 0.5 * log(2 * pi) + log(m_neq_one + 0i) - log(2) + x^2 + 
			log_erf(-x) - 3 / 2 * log(s_neq_one - 1 + 0i)

		max <- log_a
		max[ Re(max) < Re(log_b) ] <- log_b[ Re(max) < Re(log_b) ]
		max[ Re(max) < Re(log_c) ] <- log_c[ Re(max) < Re(log_c) ]
		max[ Re(max) < Re(log_d) ] <- log_d[ Re(max) < Re(log_d) ]

		add <- exp(log_a - max) + exp(log_b - max) + exp(log_c - max) + exp(log_d - max)

		result[ ! eq_one] <- Re(log(add) + max)
	}
	
	if (any(eq_one)) {

		to_sel <- eq_one & m != 0

		m_eq_one <- m[ to_sel ]

		result[ to_sel ] <- -2 * log(abs(m_eq_one)) + 0.5 * m_eq_one^2 + pexp(m_eq_one^2, 0.5, log.p = TRUE)

		to_sel <- eq_one & m == 0
		
		result[ to_sel ]  <- -log(2)
	}

	result
}


dlog_conv_SB_dm <- function(m, s) {

	eq_one <- abs(s - 1) < 1e-3
	result <- rep(0, max(length(m), length(s)))

	if (any(! eq_one)) {

		m_neq_one <- m[ ! eq_one & m != 0 ]
		s_neq_one <- s[ ! eq_one & m != 0]

		x <- m_neq_one / sqrt(s_neq_one - 1 + 0i) / sqrt(2)
		dxdm <- 1 / sqrt(s_neq_one - 1 + 0i) / sqrt(2)

		log_a <- 0.5 * log(s_neq_one) + 0.5 * m_neq_one^2 / s_neq_one - log(s_neq_one - 1 + 0i)
		log_dlog_a_dm <- log(m_neq_one + 0i) - log(s_neq_one)
		log_c <- 0.5 * log(2 * pi) + log(m_neq_one + 0i) - log(2) + x^2 + 
			log_erf(-x / sqrt(s_neq_one)) - 3 / 2 * log(s_neq_one - 1 + 0i) + log(-1 + 0i)
		log_dlog_c_dm <- log(1 / m_neq_one + 2 * x * dxdm - exp(log_dlog_erf_dx(-x / sqrt(s_neq_one))) / sqrt(s_neq_one) * dxdm) 
		log_d <- 0.5 * log(2 * pi) + log(m_neq_one + 0i) - log(2) + x^2 + 
			log_erf(-x) - 3 / 2 * log(s_neq_one - 1 + 0i)
		log_dlog_d_dm <- log(1 / m_neq_one + 2 * x * dxdm - exp(log_dlog_erf_dx(-x)) * dxdm)
	
		log_conv <- log_conv_SB(m_neq_one, s_neq_one)

		value_a <- log_a + log_dlog_a_dm - log_conv; value_c <- log_c + log_dlog_c_dm - log_conv; value_d <- log_d + log_dlog_d_dm - log_conv

		max <- value_a
		max[ Re(max) < Re(value_c) ] <- (value_c)[ Re(max) < Re(value_c) ]
		max[ Re(max) < Re(value_d) ] <- (value_d)[ Re(max) < Re(value_d)]

		add <- exp(value_a - max) + exp(value_c - max) + exp(value_d - max) 

		result[ ! eq_one & m != 0 ] <- Re(exp(log(add) + max))

		result[ ! eq_one & m == 0 ] <- 0
	}
	
	if (any(eq_one & m != 0)) {

		to_sel <- eq_one & m != 0

		s_eq_one <- s[ to_sel ]
		m_eq_one <- m[ to_sel ]

		result[ to_sel ] <- Re(-2 / m_eq_one + m_eq_one + exp(-pexp(m_eq_one^2, 0.5, log.p = TRUE) + 
			dexp(m_eq_one^2, 0.5, log = TRUE)) * 2 * m_eq_one)
	}
	
	if (any(eq_one & m == 0)) {

		result[ eq_one & m == 0 ] <- 0

	}

	result
}

dlog_conv_SB_ds <- function(m, s) {

	eq_one <- abs(s - 1) < 1e-3
	result <- rep(0, max(length(m), length(s)))

	if (any(! eq_one)) {

		m_neq_one <- m[ ! eq_one ]
		s_neq_one <- s[ ! eq_one ]

		x <- m_neq_one / sqrt(s_neq_one - 1 + 0i) / sqrt(2)
		dxds <- -0.5 * m_neq_one / (s_neq_one - 1 + 0i)^(3/2) / sqrt(2)

		log_a <- 0.5 * log(s_neq_one)  + 0.5 * m_neq_one^2 / s_neq_one - log(s_neq_one - 1 + 0i)
		log_dlog_a_ds <- log(0.5 / s_neq_one - 0.5 * m_neq_one^2 / s_neq_one^2 - 1 / (s_neq_one - 1) + 0i)
		log_b <- 0 + log(-1 + 0i) - log(s_neq_one - 1 + 0i)
		log_dlog_b_ds <- - log(s_neq_one - 1 + 0i) + log(-1 + 0i)
		log_c <- 0.5 * log(2 * pi) + log(m_neq_one + 0i) - log(2) + x^2 + 
			log_erf(-x / sqrt(s_neq_one)) - 3 / 2 * log(s_neq_one - 1 + 0i) + log(-1 + 0i)
		log_dlog_c_ds <- log(2 * x * dxds - exp(log_dlog_erf_dx(-x / sqrt(s_neq_one))) * (1 / sqrt(s_neq_one) * dxds  - 
			0.5 / s_neq_one^(3/2) * x) - 3 / 2 / (s_neq_one - 1) + 0i)
		log_d <- 0.5 * log(2 * pi) + log(m_neq_one + 0i) - log(2) + x^2 + log_erf(-x) - 3 / 2 * log(s_neq_one - 1 + 0i)
		log_dlog_d_ds <- log(2 * x * dxds - exp(log_dlog_erf_dx(-x)) * dxds - 3 / 2 / (s_neq_one - 1) + 0i)
	
		log_conv <- log_conv_SB(m_neq_one, s_neq_one)

		value_a <- log_a + log_dlog_a_ds - log_conv; 
		value_b <- log_b + log_dlog_b_ds - log_conv; 
		value_c <- log_c + log_dlog_c_ds - log_conv; 
		value_d <- log_d + log_dlog_d_ds - log_conv

		max <- value_a
		max[ Re(max) < Re(value_b) ] <- (value_b)[ Re(max) < Re(value_b) ]
		max[ Re(max) < Re(value_c) ] <- (value_c)[ Re(max) < Re(value_c) ]
		max[ Re(max) < Re(value_d) ] <- (value_d)[ Re(max) < Re(value_d)]

		add <- exp(value_a - max) + exp(value_b - max) + exp(value_c - max) + exp(value_d - max) 

		result[ ! eq_one ] <- Re(exp(log(add) + max))
	}
	
	if (any(eq_one & abs(m) >  1e-3)) {

		to_sel <- eq_one & abs(m) > 1e-3

		m_eq_one <- m[ to_sel ]

		log_conv <- log_conv_SB(m_eq_one, 1)

		log_s1 <- log(3) - 4 * log(abs(m_eq_one)) + 0.5 * m_eq_one^2 + pexp(0.5 * m_eq_one^2, log.p = TRUE) + log(-1 + 0i) - log_conv
		log_s2 <- - log(2) + 0.5 * m_eq_one^2 + log(3 / m_eq_one^2 - 1 + 0i) - log_conv

		max <- log_s1
		max[ Re(max) < Re(log_s2) ] <- log_s2[ Re(max) < Re(log_s2) ]

		add <- exp(log_s1 - max) + exp(log_s2 - max) 

		result[ to_sel ] <- Re(exp(log(add) + max))
	}
	
	if (any(eq_one & abs(m) <= 1e-3)) {

		to_sel <- eq_one & abs(m) <= 1e-3

		result[ to_sel ] <- - 1 / 4
	}

	result
}

d2log_conv_SB_dm2 <- function(m, s) {

	eq_one <- abs(s - 1) < 1e-3
	result <- rep(0, max(length(m), length(s)))

	if (any(! eq_one)) {

		m_neq_one <- m[ ! eq_one & m != 0 ]
		s_neq_one <- s[ ! eq_one & m != 0 ]

		x <- m_neq_one / sqrt(s_neq_one - 1 + 0i) / sqrt(2)
		dxdm <- 1 / sqrt(s_neq_one - 1 + 0i) / sqrt(2)

		log_a <- 0.5 * log(s_neq_one) + 0.5 * m_neq_one^2 / s_neq_one - log(s_neq_one - 1 + 0i)
		log_dlog_a_dm <- log(m_neq_one + 0i) - log(s_neq_one)
		log_d2log_a_dm2 <- -log(s_neq_one) 
		log_c <- 0.5 * log(2 * pi) + log(m_neq_one + 0i) - log(2) + x^2 + 
			log_erf(-x / sqrt(s_neq_one)) - 3 / 2 * log(s_neq_one - 1 + 0i) + log(-1 + 0i)
		log_dlog_c_dm <- log(1 / m_neq_one + 2 * x * dxdm - exp(log_dlog_erf_dx(-x / sqrt(s_neq_one))) / sqrt(s_neq_one) * dxdm)
		log_d2log_c_dm2 <- log(- 1 / m_neq_one^2 + 2 * dxdm^2 + exp(log_d2log_erf_dx2(-x / sqrt(s_neq_one))) / s_neq_one * dxdm^2)
		log_d <- 0.5 * log(2 * pi) + log(m_neq_one + 0i) - log(2) + x^2 + log_erf(-x) - 3 / 2 * log(s_neq_one - 1 + 0i)
		log_dlog_d_dm <- log(1 / m_neq_one + 2 * x * dxdm - exp(log_dlog_erf_dx(-x)) * dxdm)
		log_d2log_d_dm2 <- log(- 1 / m_neq_one^2 + 2 * dxdm^2 + exp(log_d2log_erf_dx2(-x)) * dxdm^2)
	
		log_conv <- log_conv_SB(m_neq_one, s_neq_one)

		value_a <- log_a + log_dlog_a_dm - log_conv + log(exp(log_dlog_a_dm) + exp(log_d2log_a_dm2 - log_dlog_a_dm)) 
		value_c <- log_c + log_dlog_c_dm - log_conv + log(exp(log_dlog_c_dm) + exp(log_d2log_c_dm2 - log_dlog_c_dm)) 
		value_d <- log_d + log_dlog_d_dm - log_conv + log(exp(log_dlog_d_dm) + exp(log_d2log_d_dm2 - log_dlog_d_dm))

		max <- value_a
		max[ Re(max) < Re(value_c) ] <- (value_c)[ Re(max) < Re(value_c) ]
		max[ Re(max) < Re(value_d) ] <- (value_d)[ Re(max) < Re(value_d)]

		add <- exp(value_a - max) + exp(value_c - max) + exp(value_d - max) 

		result[ ! eq_one & m != 0 ] <- Re(exp(log(add) + max) - dlog_conv_SB_dm(m_neq_one, s_neq_one)^2)

		m_neq_one <- m[ ! eq_one & m == 0 ]
		s_neq_one <- s[ ! eq_one & m == 0]

		result[ ! eq_one & m == 0 ] <- Re(((s_neq_one + 1) - 2 * sqrt(s_neq_one)) / 
			((s_neq_one - 1)^2 * sqrt(s_neq_one)) / exp(log_conv_SB(rep(0, length(s_neq_one)), s_neq_one)))
	}
	
	if (any(eq_one & abs(m) > 1e-5)) {

		to_sel <- eq_one & abs(m) > 1e-5

		s_eq_one <- s[ to_sel ]
		m_eq_one <- m[ to_sel ]

		result[ to_sel ] <- Re(2 / m_eq_one^2 + 1 + exp(-pexp(m_eq_one^2, 0.5, log.p = TRUE) + 
			dexp(m_eq_one^2, 0.5, log = TRUE)) * 2 + exp(-pexp(m_eq_one^2, 0.5, log.p = TRUE) + 
			dexp(m_eq_one^2, 0.5, log = TRUE)) * 2 * m_eq_one * (-dexp(m_eq_one^2, 0.5) / pexp(m_eq_one^2, 0.5) * 2 * m_eq_one - 
			m_eq_one))
	}
	
	if (any(eq_one & abs(m) <= 1e-5)) {
		result[ eq_one & abs(m) <= 1e-5 ] <- .5
	}

	result
}

d2log_conv_SB_ds2 <- function(m, s) {

	eq_one <- abs(s - 1) < 1e-2
	result <- rep(0, max(length(m), length(s)))

	if (any(! eq_one)) {

		m_neq_one <- m[ ! eq_one ]
		s_neq_one <- s[ ! eq_one ]

		x <- m_neq_one / sqrt(s_neq_one - 1 + 0i) / sqrt(2)
		dxds <- -0.5 * m_neq_one / (s_neq_one - 1 + 0i)^(3/2) / sqrt(2)
		d2xds2 <- 3 / 4 * m_neq_one / (s_neq_one - 1 + 0i)^(5/2) / sqrt(2)

		log_a <- 0.5 * log(s_neq_one) + 0.5 * m_neq_one^2 / s_neq_one  - log(s_neq_one - 1 + 0i)
		log_dlog_a_ds <- log(0.5 / s_neq_one - 0.5 * m_neq_one^2 / s_neq_one^2 - 1 / (s_neq_one - 1) + 0i)
		log_d2log_a_ds2 <- log(-0.5 / s_neq_one^2 + m_neq_one^2 / s_neq_one^3 + 1 / (s_neq_one - 1)^2 + 0i) 
		log_b <- 0 + log(-1 + 0i) - log(s_neq_one - 1 + 0i)
		log_dlog_b_ds <- - log(s_neq_one - 1 + 0i) + log(-1 + 0i)
		log_d2log_b_ds2 <- - 2 * log(s_neq_one - 1 + 0i) 
		log_c <- 0.5 * log(2 * pi) + log(m_neq_one + 0i) - log(2) + x^2 + 
			log_erf(-x / sqrt(s_neq_one)) - 3 / 2 * log(s_neq_one - 1 + 0i) + log(-1 + 0i)
		log_dlog_c_ds <- log(2 * x * dxds - exp(log_dlog_erf_dx(-x / sqrt(s_neq_one))) * (1 / sqrt(s_neq_one) * dxds  - 
			0.5 / s_neq_one^(3/2) * x) - 3 / 2 / (s_neq_one - 1) + 0i)
		log_d2log_c_ds2 <- log(2 * dxds^2 + 2 * x * d2xds2 - exp(log_d2log_erf_dx2(-x / sqrt(s_neq_one))) * (-dxds / sqrt(s_neq_one) + 
			0.5 * x / s_neq_one^(3/2)) * (1 / sqrt(s_neq_one) * dxds - 0.5 / s_neq_one^(3/2) * x) - 
			exp(log_dlog_erf_dx(-x / sqrt(s_neq_one))) * (-0.5 / (s_neq_one)^(3/2) * dxds + 1 / sqrt(s_neq_one) * d2xds2 + 
			3 / 4 / s_neq_one^(5/2) * x - 0.5 / s_neq_one^(3/2) * dxds) + 3 / 2 / (s_neq_one - 1)^2 + 0i)
		log_d <- 0.5 * log(2 * pi) + log(m_neq_one + 0i) - log(2) + x^2 + log_erf(-x) - 3 / 2 * log(s_neq_one - 1 + 0i)
		log_dlog_d_ds <- log(2 * x * dxds - exp(log_dlog_erf_dx(-x)) * dxds - 3 / 2 / (s_neq_one - 1) + 0i)
		log_d2log_d_ds2 <- log(2 * dxds^2 + 2 * x * d2xds2 + exp(log_d2log_erf_dx2(-x)) * dxds^2 - 
			exp(log_dlog_erf_dx(-x)) * d2xds2 + 3 / 2 / (s_neq_one - 1)^2)
	
		log_conv <- log_conv_SB(m_neq_one, s_neq_one)

		value_a <- log_a + log_dlog_a_ds - log_conv + log(exp(log_dlog_a_ds) + exp(log_d2log_a_ds2 - log_dlog_a_ds)) 
		value_b <- log_b + log_dlog_b_ds - log_conv + log(exp(log_dlog_b_ds) + exp(log_d2log_b_ds2 - log_dlog_b_ds)) 
		value_c <- log_c + log_dlog_c_ds - log_conv + log(exp(log_dlog_c_ds) + exp(log_d2log_c_ds2 - log_dlog_c_ds)) 
		value_d <- log_d + log_dlog_d_ds - log_conv + log(exp(log_dlog_d_ds) + exp(log_d2log_d_ds2 - log_dlog_d_ds))

		max <- value_a
		max[ Re(max) < Re(value_b) ] <- (value_b)[ Re(max) < Re(value_b) ]
		max[ Re(max) < Re(value_c) ] <- (value_c)[ Re(max) < Re(value_c) ]
		max[ Re(max) < Re(value_d) ] <- (value_d)[ Re(max) < Re(value_d) ]

		add <- exp(value_a - max) + exp(value_b - max) + exp(value_c - max) + exp(value_d - max) 

		result[ ! eq_one ] <- Re(exp(log(add) + max) - dlog_conv_SB_ds(m_neq_one, s_neq_one)^2)
	}
	
	if (any(eq_one & abs(m) >  1e-1)) {

		to_sel <- eq_one & abs(m) > 1e-1

		m_eq_one <- m[ to_sel ]

		log_conv <- log_conv_SB(m_eq_one, 1)

		b <- 0.5 * m_eq_one^2

		log_s1 <- log(3) - log(8) + log(exp(b) * (b^2 - 2 * b + 2) - 2) - 3 * log(b) - log_conv
		log_s2 <- - 2 * log(2) + log(b) + log(exp(b) * (b^3 - 3 * b^2 + 6 * b - 6) + 6) - 4 * log(b) - log_conv
		log_s3 <- - 2 * log(2) + log(5) + log(b) + log(exp(b) * (b^3 - 3 * b^2 + 6 * b - 6) + 6) - 4 * log(b) - log_conv
		log_s4 <- 2 * log(b) - log(2) + log((b * (b * ((b - 4) * b + 12) - 24) + 24) * exp(b) - 24) - 5 * log(b) - log_conv

		max <- log_s1
		max[ Re(max) < Re(log_s2) ] <- log_s2[ Re(max) < Re(log_s2) ]
		max[ Re(max) < Re(log_s3) ] <- log_s3[ Re(max) < Re(log_s3) ]
		max[ Re(max) < Re(log_s4) ] <- log_s4[ Re(max) < Re(log_s4) ]

		add <- exp(log_s1 - max) + exp(log_s2 - max) + exp(log_s3 - max) + exp(log_s4 - max) 

		result[ to_sel ] <- Re(exp(log(add) + max) - dlog_conv_SB_ds(m_eq_one, 1)^2)
	}
	
	if (any(eq_one & abs(m) <= 1e-1)) {

		to_sel <- eq_one & abs(m) <= 1e-1

		result[ to_sel ] <- 1 / 4 - 1 / 16
	}

	result
}





















