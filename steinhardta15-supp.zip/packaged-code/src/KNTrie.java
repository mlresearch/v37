import fig.basic.LogInfo;
import java.util.*;
import gnu.trove.map.TIntObjectMap;
import gnu.trove.map.hash.TIntObjectHashMap;
public class KNTrie implements Params { // trie for absolute discounting
	double discount, eps;
  TIntObjectMap<KNTrie> children;
	//Map<Integer,KNTrie> children;
  KNTrie init;
	int depth, maxDepth;

	// invariants:
	//  * nonZero specifies how many children have non-zero counts
	//  * numerator specifies how many times this string appears, including at the end
	//  * denominator specifies how many times this string appears, excluding at the end
	double nonZero = 0, numerator = 0, denominator = 0;
	long numQueriesLocal = 0;
	public KNTrie(int depth, int maxDepth, double eps, double discount, Params _init){
    this.init = (KNTrie)_init;
		this.depth = depth;
		this.maxDepth = maxDepth;
    this.eps = eps;
    this.discount = discount;
		numQueriesLocal = 0;
		children = new TIntObjectHashMap<KNTrie>();
		//children = new HashMap<Integer,KNTrie>();
	}
  public KNTrie(int depth){
    this.depth = depth;
		numQueriesLocal = 0;
		children = new TIntObjectHashMap<KNTrie>();
  }
  @Override
  public void add(Prefix p, int c, double wt){
    int index = maxDepth - 1;
		KNTrie prefix = this, all = this;

    while(true){
      KNTrie nextAll = all.children.get(c);
      if(nextAll == null){
        nextAll = new KNTrie(all.depth+1);
        all.children.put(c, nextAll);
      }
      all = nextAll;
      
      prefix.denominator += wt;
      double cNum = all.numerator;
      double delta = Math.min(cNum+wt,discount)
                      - Math.min(cNum,discount);
      prefix.nonZero += delta;
      all.numerator += wt;

      if(index == 0){
        return;
      }

      index = index-1;
      c = p.get(index);
			if(prefix.children.get(c) == null){
				prefix.children.put(c, new KNTrie(prefix.depth+1));
			}
      prefix = prefix.children.get(c);
    }
	}

	static long numQueries = 0;
  @Override
  public double get(Prefix ngram, int c){
		numQueries++;
		numQueriesLocal++;
		double ans = eps / Global.numWords;
		double _nonZero, _denominator, _numerator;
		int index = ngram.size();
		KNTrie prefix = this, all = this;
		KNTrie prefixInit = init, allInit = init;
		while(true){
			all = all == null ? null : all.children.get(c);
			allInit = allInit == null ? null : allInit.children.get(c);
			_denominator = 0;
      if(prefix != null) _denominator += prefix.denominator;
      if(prefixInit != null) _denominator += prefixInit.denominator;
      if(Math.abs(_denominator) < 1e-7) return ans;
			_nonZero = 0;
      if(prefix != null) _nonZero += prefix.nonZero;
      if(prefixInit != null) _nonZero += prefixInit.nonZero;
      _numerator = 0;
      if(all != null) _numerator += all.numerator;
      if(allInit != null) _numerator += allInit.numerator;

			if(index == ngram.size()-1){ // unigram probabilities
				ans = ans + (1-eps) * _numerator / (double) _denominator;
			} else {
				ans = (Math.max(_numerator - discount, 0) + _nonZero * ans) / _denominator;
			}

			if(index == 0){
				return ans;
			}
			index = index-1;
			c = ngram.get(index);
      if(prefix != null) prefix = prefix.children.get(c);
      if(prefixInit != null) prefixInit = prefixInit.children.get(c);
		}
	}
}
