import java.util.*;
public class ExpandDerivation {
  MergeDerivation prev;
  int x, y;
  int len;
  double score, localScore, back;
  public ExpandDerivation(){
    prev = null;
    x = 0;
    y = 0;
    score = 0.0;
    back = Double.NEGATIVE_INFINITY;
    len = 0;
  }
  public ExpandDerivation(MergeDerivation prev, int x, int y){
    this.prev = prev;
    this.x = x;
    this.y = y;
    localScore = Math.log(Global.pT.get(new Prefix(prev), x)) + Math.log(Global.pE[x][y]);
    score = prev.score + localScore;
    back = Double.NEGATIVE_INFINITY;
    len = prev.len + 1;
  }
  void registerLen(double logZ){
    Global.registerLen(len, Math.exp(score-logZ));
  }
  void backprop(){
    prev.back = Util.logsumexp(prev.back, back + localScore);
  }
}
