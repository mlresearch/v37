#!/usr/bin/env python

from optparse import OptionParser
parser = OptionParser()
parser.add_option("--name", type="string", dest="name")
parser.add_option("--compile", action="store_true", dest="compile", default=False)
parser.add_option("--run", action="store_true", dest="run", default=False)
parser.add_option("--java-help", action="store_true", dest="java_help", default=False)
parser.add_option("--showRecent", type="int", dest="show_recent")
parser.add_option("--tail", type="int", dest="tail", default=5)
parser.add_option("-v", "--verbose", action="store_true", dest="verbose", default=False)
parser.add_option("-g", type="int", dest="memory", default=5)
parser.add_option("--dataset", type="string", dest="dataset", default="../data/char-level")
parser.add_option("--iterations", type="int", dest="iterations", default=20)
parser.add_option("--inference", type="int", dest="inference", default=0)
parser.add_option("--ngram", type="int", dest="ngram", default=False)
parser.add_option("--kn", action="store_true", dest="kn", default=False)
parser.add_option("--updateLM", action="store_true", dest="updateLM", default=False)
parser.add_option("--B", type="int", dest="B", default=10)
parser.add_option("--discount", type="float", dest="discount", default=0.25)

(options, args) = parser.parse_args()
if not options.name:
  print "No name given, defaulting to SCRATCH"
name = options.name or "SCRATCH"

from subprocess import call
from glob import glob
import shlex
import threading
import time
include="jar/guava-14.0.1.jar:jar/fig.jar:jar/trove-3.1a1.jar"
prefix="state/execs"

if options.compile:
  call(["rm", "-f"] + glob("*.class"))
  call(["javac", "-cp", ".:%s" % include, "Main.java"])
  call(["mkdir", "-p", "classes/%s" % name])
  call(["mv"] + glob("*.class") + ["classes/%s/" % name])
  call(["mkdir", "-p", "%s/%s" % (prefix, name)])

if options.run:
  call_args = ["java", "-Xmx%dg" % options.memory, "-cp .:%s:classes/%s" % (include, name), 
               "Main", "-execPoolDir %s/%s" % (prefix, name)]
  if options.java_help:
    call_args.append("-help")
    call(shlex.split(" ".join(call_args)))
  else:
    if not options.verbose:
      call_args.append("-log.stdout false")
    B = lambda x : "true" if x else "false"
    call_args.append("-Main.experimentName %s" % name)
    call_args.append("-Main.dataSource %s" % options.dataset)
    call_args.append("-Main.numIters %d" % options.iterations)
    call_args.append("-Main.ngramLength %d" % options.ngram)
    call_args.append("-Main.KN_DISCOUNT %f" % options.discount)
    call_args.append("-Main.kn %s" % B(options.kn))
    call_args.append("-Main.updateLM %s" % B(options.updateLM))
    call_args.append("-Main.inferType %d" % options.inference)
    call_args.append("-Main.beamSize %d" % options.B)
    run_cmd = lambda : call(shlex.split(" ".join(call_args)))
    run_cmd()

if options.show_recent:
  dirs = glob("state/execs/%s/*.exec" % name)
  f = lambda s : int(s.split('/')[-1].split('.')[0])
  for dir in sorted(dirs, key=f)[-options.show_recent:]:
    call(shlex.split("tail -n %d %s/log" % (options.tail, dir)))
