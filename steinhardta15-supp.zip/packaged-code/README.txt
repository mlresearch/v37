Code and data for the ''decipherment'' task from the "Reified Context Models" 
paper. The data can be found in:

  data/char-level <-- character-level decipherment task
  data/word-level <-- word-level decipherment task (used in the paper)

The source code can be found in:

  src/

To run a simple experiment on the char-level task, just do:

cd src/
./run_default.sh

More generally, we have provided a run script, ./run.py, 
with several options. When you run the program, it will 
automatically create a folder:

src/state/execs/NAME/NUM.exec/

where NAME is the name of the experiment, specified 
by --name flag to run.py (default: SCRATCH), and 
NUM increments for each experiment run. Inside this 
folder, you will find several files, the most interesting are:

  log <-- standard out redirects here (use --verbose flag to also 
            print it to the terminal)
  options.map <-- see what options you ran with

Another interesting file is

  src/Infer.java

which contains the code for the algorithms we used. The 
updateAbstract() method is the method presented in our paper.
