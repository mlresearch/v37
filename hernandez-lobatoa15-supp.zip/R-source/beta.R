##
# This file contains the required information for carrying out approximate inference in a model
# with a beta hyper prior 
#

log_Zbeta_p <- function(aOld, bOld) {
	-lgamma(aOld + bOld + 3) + lgamma(aOld + 2) + lgamma(bOld + 1)
}

dlog_Zbeta_p_da <- function(aOld, bOld) {
	-digamma(aOld + bOld + 3) + digamma(aOld + 2) 
}

d2log_Zbeta_p_da2 <- function(aOld, bOld) {
	-trigamma(aOld + bOld + 3) + trigamma(aOld + 2) 
}

dlog_Zbeta_p_db <- function(aOld, bOld) {
	-digamma(aOld + bOld + 3) + digamma(bOld + 1) 
}

d2log_Zbeta_p_db2 <- function(aOld, bOld) {
	-trigamma(aOld + bOld + 3) + trigamma(bOld + 1) 
}

log_Zbeta_1mp <- function(aOld, bOld) {
	-lgamma(aOld + bOld + 3)  + lgamma(aOld + 1) + lgamma(bOld + 2)
}

dlog_Zbeta_1mp_da <- function(aOld, bOld) {
	-digamma(aOld + bOld + 3) + digamma(aOld + 1) 
}

d2log_Zbeta_1mp_da2 <- function(aOld, bOld) {
	-trigamma(aOld + bOld + 3) + trigamma(aOld + 1) 
}

dlog_Zbeta_1mp_db <- function(aOld, bOld) {
	-digamma(aOld + bOld + 3) + digamma(bOld + 2) 
}

d2log_Zbeta_1mp_db2 <- function(aOld, bOld) {
	-trigamma(aOld + bOld + 3) + trigamma(bOld + 2) 
}


log_Zbeta_p2 <- function(aOld, bOld) {
	-lgamma(aOld + bOld + 4) + lgamma(aOld + 3) + lgamma(bOld + 1)
}

log_Zbeta_p3 <- function(aOld, bOld) {
	-lgamma(aOld + bOld + 5) + lgamma(aOld + 4) + lgamma(bOld + 1)
}


log_Zbeta_1mp_p <- function(aOld, bOld) {
	-lgamma(aOld + bOld + 4)  + lgamma(aOld + 2) + lgamma(bOld + 2)
}

log_Zbeta_1mp_p2 <- function(aOld, bOld) {
	-lgamma(aOld + bOld + 5)  + lgamma(aOld + 3) + lgamma(bOld + 2)
}



